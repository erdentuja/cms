<?php
require_once 'config.php';
require_once 'core/UrlHelper.php';
require_once 'core/functions.php';

// ---------- Ütemezett bejegyzések auto-publikálása ----------
try {
    $db->exec("UPDATE posts SET status = 'published' WHERE status = 'scheduled' AND publish_at IS NOT NULL AND publish_at <= NOW()");
} catch (PDOException $e) {
    // publish_at mező még nem létezik – migráció szükséges
}

// ---------- Slug alapú oldal lekérdezés ----------
$slug = UrlHelper::sanitizeSlug($_GET['route'] ?? 'index');

$stmt = $db->prepare("SELECT * FROM posts WHERE slug = ? AND status = 'published' AND deleted_at IS NULL LIMIT 1");
$stmt->execute([$slug]);
$page = $stmt->fetch();

if (!$page) {
    $page = [
        'title' => 'Üdvözöljük',
        'content' => '<p>Kezdje el a tartalomépítést az adminban!</p>',
    ];
}

// ---------- Beállítások ----------
$settings = [];
$settingsQuery = $db->query("SELECT * FROM settings");
while ($row = $settingsQuery->fetch()) {
    $settings[$row['setting_key']] = json_decode($row['setting_value'], true);
}

// ---------- Megjelenítés ----------
include 'theme/header.php';
?>
<div class="container">
    <h1><?php echo htmlspecialchars($page['title']); ?></h1>
    <div class="page-content">
        <?php echo $page['content']; // HTML tartalom – WYSIWYG szerkesztőből ?>
    </div>
</div>
<?php
include 'theme/footer.php';