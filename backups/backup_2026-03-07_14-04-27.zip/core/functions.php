<?php
function current_user_role()
{
    return $_SESSION['admin_role'] ?? 'registered';
}
function is_super_admin()
{
    return current_user_role() === 'super_admin';
}
function is_admin()
{
    $role = current_user_role();
    return $role === 'super_admin' || $role === 'admin';
}

function render_seo_tags($page, $settings)
{
    $site_name = $settings['site_info']['name'] ?? 'CMS';
    $title = !empty($page['meta_title']) ? $page['meta_title'] : ($page['title'] ?? 'Főoldal');
    $desc = !empty($page['meta_description']) ? $page['meta_description'] : ($settings['site_info']['description'] ?? '');
    echo "<title>" . htmlspecialchars($title) . " | " . htmlspecialchars($site_name) . "</title>\n";
    echo '<meta name="description" content="' . htmlspecialchars($desc) . '">' . "\n";
}
function render_menu($db)
{
    $items = $db->query("SELECT * FROM menus ORDER BY sort_order ASC")->fetchAll();
    echo "<ul>";
    foreach ($items as $item) {
        $url = (strpos($item['url'], 'http') === 0) ? $item['url'] : UrlHelper::link($item['url']);
        echo "<li><a href='" . htmlspecialchars($url) . "'>" . htmlspecialchars($item['label']) . "</a></li>";
    }
    echo "</ul>";
}

function log_activity($db, $action, $targetType = null, $targetId = null, $targetTitle = null, $details = null)
{
    $userId = $_SESSION['admin_id'] ?? null;
    $username = $_SESSION['admin_user'] ?? 'ismeretlen';
    $ip = $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';

    try {
        $stmt = $db->prepare(
            'INSERT INTO activity_log (user_id, username, action, target_type, target_id, target_title, details, ip_address)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?)'
        );
        $stmt->execute([$userId, $username, $action, $targetType, $targetId, $targetTitle, $details, $ip]);
    } catch (PDOException $e) {
        // Tábla még nem létezik – silent fail
    }
}
?>