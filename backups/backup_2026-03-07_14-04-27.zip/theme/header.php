<?php
require_once __DIR__ . '/../core/functions.php';
require_once __DIR__ . '/../core/UrlHelper.php';
?>
<!DOCTYPE html>
<html lang="hu">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php render_seo_tags($page, $settings); ?>
    <link rel="stylesheet" href="<?php echo UrlHelper::themeAsset('style.css'); ?>">
</head>

<body>
    <header>
        <div class="container">
            <a href="<?php echo UrlHelper::link(); ?>" class="site-title">
                <?php if (!empty($settings['site_info']['logo'])): ?>
                    <img src="<?php echo UrlHelper::asset($settings['site_info']['logo']); ?>"
                        alt="<?php echo htmlspecialchars($settings['site_info']['name'] ?? 'CMS'); ?>"
                        style="max-height: 45px;">
                <?php else: ?>
                    <?php echo htmlspecialchars($settings['site_info']['name'] ?? 'CMS'); ?>
                <?php endif; ?>
            </a>
            <nav>
                <?php render_menu($db); ?>
            </nav>
        </div>
    </header>
    <div class="content">