</div><!-- /.content -->
<footer>
    <div class="container">
        <p>
            <?php echo htmlspecialchars($settings['design']['footer_text'] ?? '© ' . date('Y')); ?>
        </p>
    </div>
</footer>
</body>

</html>