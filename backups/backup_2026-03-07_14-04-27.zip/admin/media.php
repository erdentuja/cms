<?php
require_once '../config.php';
require_once '../core/UrlHelper.php';
require_once '../core/ImageProcessor.php';
require_once 'layout.php';

if (!isset($_SESSION['admin_id'])) {
    header('Location: index.php');
    exit;
}

if (!is_admin()) {
    header('Location: index.php');
    exit;
}

// ---------- Engedélyezett fájltípusok ----------
$allowedTypes = ['image/jpeg', 'image/png', 'image/gif', 'image/webp', 'image/svg+xml', 'application/pdf'];
$allowedExts = ['jpg', 'jpeg', 'png', 'gif', 'webp', 'svg', 'pdf'];
$maxSize = 5 * 1024 * 1024; // 5 MB

$message = '';
$messageType = '';

// ---------- Feltöltés (hagyományos form) ----------
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['file']) && $_FILES['file']['error'] === UPLOAD_ERR_OK) {
    if (!csrf_verify()) {
        $message = 'Érvénytelen kérés.';
        $messageType = 'error';
    } else {
        $file = $_FILES['file'];
        $result = processUpload($file, $db);

        $message = $result['message'];
        $messageType = $result['type'];
    }
}

// ---------- Alt text és Caption frissítés ----------
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_media_id'])) {
    if (csrf_verify()) {
        $mediaId = $_POST['update_media_id'];
        $altText = trim($_POST['alt_text'] ?? '');
        $caption = trim($_POST['caption'] ?? '');

        $stmt = $db->prepare('UPDATE media SET alt_text = ?, caption = ? WHERE id = ?');
        $stmt->execute([$altText, $caption, $mediaId]);

        $message = 'Média információk frissítve!';
        $messageType = 'success';
    }
}

// ---------- Törlés ----------
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_id'])) {
    if (csrf_verify()) {
        $stmt = $db->prepare('SELECT * FROM media WHERE id = ?');
        $stmt->execute([$_POST['delete_id']]);
        $item = $stmt->fetch();
        if ($item) {
            // Töröljük az összes generált verziót is
            $filepath = '../uploads/' . $item['filepath'];
            if (file_exists($filepath)) {
                unlink($filepath);
            }

            // Töröljük a generált méreteket
            if (!empty($item['sizes'])) {
                $sizes = json_decode($item['sizes'], true);
                if ($sizes && is_array($sizes)) {
                    $dir = dirname($filepath);
                    foreach ($sizes as $sizeData) {
                        if (is_array($sizeData)) {
                            foreach ($sizeData as $sizePath) {
                                $fullPath = $dir . '/' . $sizePath;
                                if (file_exists($fullPath)) {
                                    unlink($fullPath);
                                }
                            }
                        }
                    }
                }
            }

            $db->prepare('DELETE FROM media WHERE id = ?')->execute([$item['id']]);
            log_activity($db, 'delete', 'media', (int) $item['id'], $item['filename']);
            $message = 'Fájl törölve.';
            $messageType = 'success';
        }
    }
}

/**
 * Feltöltés feldolgozása (közös függvény)
 */
function processUpload($file, $db) {
    global $allowedExts, $allowedTypes, $maxSize;

    $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    $mime = mime_content_type($file['tmp_name']);
    $fileSize = $file['size'];

    if (!in_array($ext, $allowedExts)) {
        return ['message' => 'Nem engedélyezett fájltípus: .' . htmlspecialchars($ext), 'type' => 'error'];
    }

    if (!in_array($mime, $allowedTypes)) {
        return ['message' => 'Nem engedélyezett MIME típus: ' . htmlspecialchars($mime), 'type' => 'error'];
    }

    if ($fileSize > $maxSize) {
        return ['message' => 'A fájl túl nagy! Maximum: 5 MB.', 'type' => 'error'];
    }

    // Feltöltési könyvtár
    $sub = date('Y/m');
    $dir = '../uploads/' . $sub;
    if (!is_dir($dir)) {
        mkdir($dir, 0755, true);
    }

    // Egyedi fájlnév generálás
    $baseName = time() . '_' . bin2hex(random_bytes(4));
    $fileName = $baseName . '.' . $ext;
    $filePath = $dir . '/' . $fileName;

    // Fájl feltöltése
    if (!move_uploaded_file($file['tmp_name'], $filePath)) {
        return ['message' => 'Feltöltési hiba történt.', 'type' => 'error'];
    }

    // Kép esetén: átméretezés és WebP generálás
    $width = null;
    $height = null;
    $sizes = null;

    if (in_array($ext, ['jpg', 'jpeg', 'png', 'gif', 'webp'])) {
        $imageInfo = ImageProcessor::getImageInfo($filePath);
        if ($imageInfo) {
            $width = $imageInfo['width'];
            $height = $imageInfo['height'];

            // Különböző méretek generálása
            $generatedSizes = ImageProcessor::generateSizes($filePath, $dir, $baseName);

            // WebP verziók generálása
            $webpVersions = ImageProcessor::generateWebPVersions($filePath, $generatedSizes, $dir, $baseName);

            // Összefűzzük a méreteket és WebP verziókat
            $generatedSizes['webp'] = $webpVersions;
            $sizes = json_encode($generatedSizes);
        }
    }

    // Adatbázisba mentés
    $stmt = $db->prepare('INSERT INTO media (filename, filepath, file_size, mime_type, width, height, sizes) VALUES (?, ?, ?, ?, ?, ?, ?)');
    $stmt->execute([
        $file['name'],
        $sub . '/' . $fileName,
        $fileSize,
        $mime,
        $width,
        $height,
        $sizes
    ]);

    $mediaId = $db->lastInsertId();
    log_activity($db, 'create', 'media', (int)$mediaId, $file['name']);

    return ['message' => 'Fájl sikeresen feltöltve és feldolgozva!', 'type' => 'success'];
}

$items = $db->query('SELECT * FROM media ORDER BY id DESC')->fetchAll();

admin_header('Média kezelés');
?>

<?php if ($message): ?>
    <div class="alert alert-<?php echo $messageType; ?>"><?php echo htmlspecialchars($message); ?></div>
<?php endif; ?>

<!-- Drag & Drop feltöltés -->
<div id="drop-zone" style="border: 2px dashed #cbd5e1; border-radius: 12px; padding: 40px; text-align: center; margin-bottom: 25px; background: #f8fafc; cursor: pointer; transition: all 0.3s;">
    <div style="font-size: 3rem; margin-bottom: 10px;">📤</div>
    <h3 style="margin-bottom: 10px; color: #1e293b;">Húzd ide a fájlokat vagy kattints a tallózáshoz</h3>
    <p style="color: #64748b; font-size: 0.9rem;">Engedélyezett: JPG, PNG, GIF, WebP, SVG, PDF – Max: 5 MB</p>
    <input type="file" id="file-input" multiple accept=".jpg,.jpeg,.png,.gif,.webp,.svg,.pdf" style="display: none;">
</div>

<!-- Feltöltési progress -->
<div id="upload-progress" style="display: none; margin-bottom: 20px;">
    <div style="background: #e0e7ff; border-radius: 8px; padding: 15px;">
        <div style="display: flex; justify-content: space-between; margin-bottom: 8px;">
            <span id="upload-status">Feltöltés...</span>
            <span id="upload-percent">0%</span>
        </div>
        <div style="background: #cbd5e1; height: 8px; border-radius: 4px; overflow: hidden;">
            <div id="progress-bar" style="background: #6366f1; height: 100%; width: 0%; transition: width 0.3s;"></div>
        </div>
    </div>
</div>

<!-- Hagyományos form (fallback) -->
<details style="margin-bottom: 25px;">
    <summary style="cursor: pointer; color: #6366f1; font-weight: 600;">📎 Hagyományos feltöltés (ha a drag & drop nem működik)</summary>
    <form method="post" enctype="multipart/form-data" style="margin-top: 15px;">
        <?php echo csrf_field(); ?>
        <div class="form-inline">
            <input type="file" name="file" accept=".jpg,.jpeg,.png,.gif,.webp,.svg,.pdf" required>
            <button type="submit" class="btn">📤 Feltöltés</button>
        </div>
    </form>
</details>

<!-- Média lista -->
<?php if (empty($items)): ?>
    <p style="color: #94a3b8;">Nincs még feltöltött média.</p>
<?php else: ?>
    <div style="display: grid; grid-template-columns: repeat(auto-fill, minmax(250px, 1fr)); gap: 15px;">
        <?php foreach ($items as $i): ?>
            <div style="border: 1px solid #e5e7eb; border-radius: 8px; overflow: hidden; background: #fff;">
                <?php
                $ext = strtolower(pathinfo($i['filepath'], PATHINFO_EXTENSION));
                $isImage = in_array($ext, ['jpg', 'jpeg', 'png', 'gif', 'webp', 'svg']);
                ?>

                <?php if ($isImage): ?>
                    <div style="position: relative; cursor: pointer;" onclick="openMediaDetailModal(<?php echo htmlspecialchars(json_encode($i)); ?>)">
                        <img src="../uploads/<?php echo htmlspecialchars($i['filepath']); ?>"
                            style="width: 100%; height: 180px; object-fit: cover; display: block;"
                            alt="<?php echo htmlspecialchars($i['alt_text'] ?: $i['filename']); ?>">
                        <?php if (!empty($i['width']) && !empty($i['height'])): ?>
                            <div style="position: absolute; bottom: 5px; right: 5px; background: rgba(0,0,0,0.7); color: #fff; padding: 3px 8px; border-radius: 4px; font-size: 0.7rem;">
                                <?php echo $i['width']; ?> × <?php echo $i['height']; ?>
                            </div>
                        <?php endif; ?>
                    </div>
                <?php else: ?>
                    <div style="width: 100%; height: 180px; display: flex; align-items: center; justify-content: center; background: #f1f5f9; font-size: 3rem; cursor: pointer;" onclick="openMediaDetailModal(<?php echo htmlspecialchars(json_encode($i)); ?>)">
                        📄
                    </div>
                <?php endif; ?>

                <div style="padding: 12px;">
                    <div style="white-space: nowrap; overflow: hidden; text-overflow: ellipsis; font-weight: 600; margin-bottom: 4px;"
                        title="<?php echo htmlspecialchars($i['filename']); ?>">
                        <?php echo htmlspecialchars($i['filename']); ?>
                    </div>

                    <?php if (!empty($i['file_size'])): ?>
                        <div style="font-size: 0.75rem; color: #64748b; margin-bottom: 8px;">
                            <?php echo number_format($i['file_size'] / 1024, 1); ?> KB
                        </div>
                    <?php endif; ?>

                    <div style="display: flex; gap: 5px;">
                        <button type="button" class="btn" onclick="openMediaDetailModal(<?php echo htmlspecialchars(json_encode($i)); ?>)" style="flex: 1; padding: 4px 8px; font-size: 0.75rem;">
                            ✏️ Részletek
                        </button>
                        <form method="post" style="display: inline; flex: 1;" onsubmit="return confirm('Biztosan törlöd?');">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="delete_id" value="<?php echo $i['id']; ?>">
                            <button type="submit" class="btn btn-danger" style="width: 100%; padding: 4px 8px; font-size: 0.75rem;">🗑️</button>
                        </form>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
<?php endif; ?>

<!-- Média részletek modal -->
<div id="media-detail-modal" style="display: none; position: fixed; inset: 0; background: rgba(0,0,0,0.7); z-index: 9999; justify-content: center; align-items: center;">
    <div style="background: #fff; border-radius: 12px; width: 90%; max-width: 600px; max-height: 90vh; overflow-y: auto;">
        <div style="padding: 15px 20px; border-bottom: 1px solid #e5e7eb; display: flex; justify-content: space-between; align-items: center; position: sticky; top: 0; background: #fff; z-index: 1;">
            <h3 style="margin: 0;">🖼️ Média részletek</h3>
            <button onclick="closeMediaDetailModal()" style="background: none; border: none; font-size: 1.5rem; cursor: pointer; color: #64748b;">✕</button>
        </div>
        <div id="media-detail-content" style="padding: 20px;">
            <!-- Dinamikusan töltődik JavaScript-tel -->
        </div>
    </div>
</div>

<script>
// ========================================
// DRAG & DROP FELTÖLTÉS
// ========================================
const dropZone = document.getElementById('drop-zone');
const fileInput = document.getElementById('file-input');
const uploadProgress = document.getElementById('upload-progress');
const progressBar = document.getElementById('progress-bar');
const uploadStatus = document.getElementById('upload-status');
const uploadPercent = document.getElementById('upload-percent');

// Kattintásra file input megnyitása
dropZone.addEventListener('click', () => fileInput.click());

// Drag & Drop események
dropZone.addEventListener('dragover', (e) => {
    e.preventDefault();
    dropZone.style.borderColor = '#6366f1';
    dropZone.style.background = '#e0e7ff';
});

dropZone.addEventListener('dragleave', () => {
    dropZone.style.borderColor = '#cbd5e1';
    dropZone.style.background = '#f8fafc';
});

dropZone.addEventListener('drop', (e) => {
    e.preventDefault();
    dropZone.style.borderColor = '#cbd5e1';
    dropZone.style.background = '#f8fafc';

    const files = e.dataTransfer.files;
    if (files.length > 0) {
        uploadFiles(files);
    }
});

// File input változás
fileInput.addEventListener('change', (e) => {
    const files = e.target.files;
    if (files.length > 0) {
        uploadFiles(files);
    }
});

// Fájlok feltöltése
function uploadFiles(files) {
    const formData = new FormData();
    let totalFiles = files.length;
    let uploadedFiles = 0;

    uploadProgress.style.display = 'block';
    progressBar.style.width = '0%';
    uploadStatus.textContent = `Feltöltés: 0 / ${totalFiles}`;
    uploadPercent.textContent = '0%';

    // Minden fájl egyesével
    Array.from(files).forEach((file, index) => {
        const xhr = new XMLHttpRequest();
        const fileFormData = new FormData();
        fileFormData.append('file', file);

        // CSRF token hozzáadása
        const csrfInput = document.querySelector('input[name="csrf_token"]');
        if (csrfInput) {
            fileFormData.append('csrf_token', csrfInput.value);
        }

        xhr.upload.addEventListener('progress', (e) => {
            if (e.lengthComputable) {
                const percentComplete = Math.round((e.loaded / e.total) * 100);
                const totalPercent = Math.round(((uploadedFiles + (percentComplete / 100)) / totalFiles) * 100);
                progressBar.style.width = totalPercent + '%';
                uploadPercent.textContent = totalPercent + '%';
            }
        });

        xhr.addEventListener('load', () => {
            uploadedFiles++;
            uploadStatus.textContent = `Feltöltés: ${uploadedFiles} / ${totalFiles}`;

            if (uploadedFiles === totalFiles) {
                uploadStatus.textContent = '✅ Feltöltés kész!';
                progressBar.style.width = '100%';
                uploadPercent.textContent = '100%';

                setTimeout(() => {
                    location.reload();
                }, 1500);
            }
        });

        xhr.addEventListener('error', () => {
            uploadStatus.textContent = '❌ Hiba történt a feltöltés közben!';
        });

        xhr.open('POST', 'media.php');
        xhr.send(fileFormData);
    });
}

// ========================================
// MÉDIA RÉSZLETEK MODAL
// ========================================
function openMediaDetailModal(media) {
    const modal = document.getElementById('media-detail-modal');
    const content = document.getElementById('media-detail-content');

    const isImage = ['jpg', 'jpeg', 'png', 'gif', 'webp', 'svg'].includes(media.filepath.split('.').pop().toLowerCase());

    let html = '';

    if (isImage) {
        html += `<img src="../uploads/${media.filepath}" style="width: 100%; max-height: 300px; object-fit: contain; border-radius: 8px; margin-bottom: 20px;">`;
    }

    html += `
        <form method="post">
            <input type="hidden" name="csrf_token" value="${document.querySelector('input[name="csrf_token"]').value}">
            <input type="hidden" name="update_media_id" value="${media.id}">

            <div class="form-group" style="margin-bottom: 15px;">
                <label style="display: block; margin-bottom: 5px; font-weight: 600;">Fájlnév:</label>
                <div style="color: #64748b;">${media.filename}</div>
            </div>

            <div class="form-group" style="margin-bottom: 15px;">
                <label style="display: block; margin-bottom: 5px; font-weight: 600;">Útvonal:</label>
                <code style="background: #f1f5f9; padding: 4px 8px; border-radius: 4px; font-size: 0.85rem;">/uploads/${media.filepath}</code>
            </div>

            ${media.width && media.height ? `
            <div class="form-group" style="margin-bottom: 15px;">
                <label style="display: block; margin-bottom: 5px; font-weight: 600;">Méret:</label>
                <div style="color: #64748b;">${media.width} × ${media.height} px</div>
            </div>
            ` : ''}

            ${media.file_size ? `
            <div class="form-group" style="margin-bottom: 15px;">
                <label style="display: block; margin-bottom: 5px; font-weight: 600;">Fájlméret:</label>
                <div style="color: #64748b;">${(media.file_size / 1024).toFixed(1)} KB</div>
            </div>
            ` : ''}

            <div class="form-group" style="margin-bottom: 15px;">
                <label style="display: block; margin-bottom: 5px; font-weight: 600;">Alt text (SEO):</label>
                <input type="text" name="alt_text" value="${media.alt_text || ''}" style="width: 100%;" placeholder="pl.: Gyönyörű táj naplementében">
            </div>

            <div class="form-group" style="margin-bottom: 15px;">
                <label style="display: block; margin-bottom: 5px; font-weight: 600;">Képleírás:</label>
                <textarea name="caption" style="width: 100%; height: 80px;" placeholder="Opcionális leírás a képről...">${media.caption || ''}</textarea>
            </div>

            <button type="submit" class="btn btn-success" style="width: 100%;">💾 Mentés</button>
        </form>
    `;

    content.innerHTML = html;
    modal.style.display = 'flex';
}

function closeMediaDetailModal() {
    document.getElementById('media-detail-modal').style.display = 'none';
}

// ESC = modal bezárása
document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') {
        closeMediaDetailModal();
    }
});
</script>

<?php
admin_footer();
