<?php
require_once __DIR__ . '/../core/functions.php';
require_once __DIR__ . '/../core/UrlHelper.php';
?>
<!DOCTYPE html>
<html lang="hu">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php render_seo_tags($page, $settings); ?>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link
        href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&family=Playfair+Display:wght@400;500;600;700;800&display=swap"
        rel="stylesheet">
    <link rel="stylesheet" href="<?php echo UrlHelper::themeAsset('style.css'); ?>">
</head>

<body>
    <header class="mindly-header">
        <div class="container header-container">
            <a href="<?php echo UrlHelper::link(); ?>" class="site-title">
                <?php if (!empty($settings['site_info']['logo'])): ?>
                    <img src="<?php echo UrlHelper::asset($settings['site_info']['logo']); ?>"
                        alt="<?php echo htmlspecialchars($settings['site_info']['name'] ?? 'Mindly'); ?>">
                <?php else: ?>
                    <span class="logo-text">
                        <?php echo htmlspecialchars($settings['site_info']['name'] ?? 'Mindly'); ?>
                    </span>
                <?php endif; ?>
            </a>
            
            <nav class="main-nav">
                <?php render_menu($db); ?>
            </nav>

            <div class="header-actions">
                <a href="#login" class="nav-link">Log In</a>
                <a href="#start" class="btn-dark-pill">Get Started</a>
            </div>
        </div>
    </header>
    <div class="content">