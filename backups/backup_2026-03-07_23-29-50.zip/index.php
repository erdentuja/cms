<?php
require_once 'config.php';
require_once 'core/UrlHelper.php';
require_once 'core/functions.php';

// ---------- Ütemezett bejegyzések auto-publikálása ----------
try {
    $db->exec("UPDATE posts SET status = 'published' WHERE status = 'scheduled' AND publish_at IS NOT NULL AND publish_at <= NOW()");
} catch (PDOException $e) {
    // publish_at mező még nem létezik – migráció szükséges
}

// ---------- Slug alapú oldal lekérdezés ----------
$slug = UrlHelper::sanitizeSlug($_GET['route'] ?? 'index');

$stmt = $db->prepare("SELECT * FROM posts WHERE slug = ? AND status = 'published' AND deleted_at IS NULL LIMIT 1");
$stmt->execute([$slug]);
$page = $stmt->fetch();

if (!$page) {
    $page = [
        'title' => 'Üdvözöljük',
        'content' => '<p>Kezdje el a tartalomépítést az adminban!</p>',
    ];
}

// ---------- Beállítások ----------
$settings = [];
$settingsQuery = $db->query("SELECT * FROM settings");
while ($row = $settingsQuery->fetch()) {
    $settings[$row['setting_key']] = json_decode($row['setting_value'], true);
}

// ---------- Megjelenítés ----------
include 'theme/header.php';

if ($slug === 'index' || $slug === ''): ?>
    <section class="hero">
        <div class="container">
            <h1 style="color: #fff; font-size: 3rem; margin-bottom: 20px;">
                <?php echo htmlspecialchars($settings['hero']['title'] ?? 'Üdvözöljük a LEXODUS Kft. megújult oldalán'); ?>
            </h1>
            <p style="color: rgba(255,255,255,0.9); font-size: 1.2rem; max-width: 800px; margin: 0 auto 30px auto;">
                <?php echo nl2br(htmlspecialchars($settings['hero']['description'] ?? 'Az IFS magyarországi képviselete...')); ?>
            </p>
            <div style="display: flex; gap: 15px; justify-content: center;">
                <?php if (!empty($settings['hero']['btn1_text'])): ?>
                    <a href="<?php echo htmlspecialchars($settings['hero']['btn1_link'] ?? '#services'); ?>" class="btn-modern">
                        <?php echo htmlspecialchars($settings['hero']['btn1_text']); ?>
                    </a>
                <?php endif; ?>

                <?php if (!empty($settings['hero']['btn2_text'])): ?>
                    <a href="<?php echo htmlspecialchars($settings['hero']['btn2_link'] ?? '/kapcsolat'); ?>" class="btn-modern"
                        style="background: rgba(255,255,255,0.1); border: 1px solid rgba(255,255,255,0.3); backdrop-filter: blur(5px);">
                        <?php echo htmlspecialchars($settings['hero']['btn2_text']); ?>
                    </a>
                <?php endif; ?>
            </div>
        </div>
    </section>
<?php endif; ?>

<div class="container" style="padding-top: 40px;">
    <?php if ($slug !== 'index' && $slug !== ''): ?>
        <h1 style="border-bottom: 3px solid #003366; padding-bottom: 10px; display: inline-block;">
            <?php echo htmlspecialchars($page['title']); ?>
        </h1>
    <?php endif; ?>
    <div class="page-content">
        <?php
        // Tartalom megjelenítése shortcode-okkal
        $content = parse_shortcodes($db, $page['content'] ?? '');
        echo $content;
        ?>
    </div>
</div>

<?php if ($slug === 'index' || $slug === ''): ?>
    <section class="path-section container">
        <h2 class="font-serif" style="margin-bottom: 8px;">A path to feeling better</h2>
        <p style="margin-bottom: 0;">Mindly helps you understand what's going on beneath the surface, without judgment and
            without pressure.</p>

        <div class="features-grid">
            <div class="feature-card">
                <div class="ill-mood"></div>
                <!-- Mini icon placeholder for mood -->
                <div
                    style="width: 40px; height: 40px; background: #fff; border-radius: 8px; box-shadow: 0 4px 10px rgba(0,0,0,0.1); position: absolute; top: 30px; left: 30px; display: flex; align-items: center; justify-content: center; font-size: 1.2rem;">
                    📝</div>
                <div>
                    <h3 class="feature-title">Track your mood</h3>
                    <p class="feature-text">Capture how you feel throughout the day with quick, intuitive check-ins.</p>
                </div>
            </div>

            <div class="feature-card">
                <div class="ill-pattern">✧ ✦</div>
                <div
                    style="width: 40px; height: 40px; background: #fff; border-radius: 8px; box-shadow: 0 4px 10px rgba(0,0,0,0.1); position: absolute; top: 30px; left: 30px; display: flex; align-items: center; justify-content: center; font-size: 1.2rem;">
                    🔍</div>
                <div>
                    <h3 class="feature-title">Spot the patterns</h3>
                    <p class="feature-text">See the cycles, triggers, and habits shaping your emotional world, presented
                        clearly, not clinically.</p>
                </div>
            </div>

            <div class="feature-card">
                <div class="ill-bubbles"></div>
                <div
                    style="width: 40px; height: 40px; background: #fff; border-radius: 8px; box-shadow: 0 4px 10px rgba(0,0,0,0.1); position: absolute; top: 30px; left: 30px; display: flex; align-items: center; justify-content: center; font-size: 1.2rem;">
                    🤝</div>
                <div>
                    <h3 class="feature-title">Get gentle guidance</h3>
                    <p class="feature-text">Dive into insights, reflections, and community answers tailored to what you're
                        experiencing.</p>
                </div>
            </div>

            <div class="feature-card">
                <div class="ill-tags">
                    <div class="ill-tag">Anxious</div>
                    <div class="ill-tag active">Happy</div>
                    <div class="ill-tag">Upset</div>
                </div>
                <div
                    style="width: 40px; height: 40px; background: #fff; border-radius: 8px; box-shadow: 0 4px 10px rgba(0,0,0,0.1); position: absolute; top: 30px; left: 30px; display: flex; align-items: center; justify-content: center; font-size: 1.2rem;">
                    🌱</div>
                <div>
                    <h3 class="feature-title">Grow at your pace</h3>
                    <p class="feature-text">Mindly gives you tools, not timelines. You evolve when you're ready.</p>
                </div>
            </div>
        </div>

        <div class="journey-cta">
            <a href="#journey" class="btn-dark-pill" style="padding: 16px 32px;">Begin the Journey</a>
        </div>
    </section>
<?php endif; ?>

<?php
include 'theme/footer.php';
?>