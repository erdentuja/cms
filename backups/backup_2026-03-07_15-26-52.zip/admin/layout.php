<?php
/**
 * Admin Layout Helper
 * Közös sidebar + fejléc minden admin oldalhoz.
 */
require_once __DIR__ . '/../core/functions.php';

function admin_header(string $pageTitle = 'Admin', array $topBar = []): void
{
    ?>
    <!DOCTYPE html>
    <html lang="hu">

    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>
            <?php echo htmlspecialchars($pageTitle); ?> – CMS Admin
        </title>
        <style>
            * {
                box-sizing: border-box;
                margin: 0;
                padding: 0;
            }

            body {
                display: flex;
                font-family: 'Segoe UI', Tahoma, sans-serif;
                background: #f4f7f6;
                height: 100vh;
                overflow: hidden;
            }

            nav.sidebar {
                width: 230px;
                background: #1e293b;
                color: #fff;
                padding: 25px 20px;
                flex-shrink: 0;
            }

            nav.sidebar h3 {
                margin-bottom: 25px;
                font-size: 1.2rem;
            }

            nav.sidebar a {
                display: block;
                color: #94a3b8;
                padding: 10px 12px;
                text-decoration: none;
                border-radius: 6px;
                margin-bottom: 4px;
                transition: all 0.2s;
            }

            nav.sidebar a:hover,
            nav.sidebar a.active {
                background: #334155;
                color: #fff;
            }

            nav.sidebar .logout {
                color: #f87171;
                margin-top: 30px;
            }

            nav.sidebar .logout:hover {
                background: #7f1d1d;
                color: #fff;
            }

            main.content {
                flex: 1;
                padding: 0 40px 30px 40px;
                overflow-y: auto;
            }

            main.content h2 {
                margin-bottom: 20px;
                color: #1e293b;
            }

            /* Form elements */
            input[type="text"],
            input[type="password"],
            input[type="url"],
            input[type="email"],
            input[type="number"],
            textarea,
            select {
                padding: 8px 12px;
                border: 1px solid #d1d5db;
                border-radius: 6px;
                font-size: 0.95rem;
                font-family: inherit;
            }

            input:focus,
            textarea:focus,
            select:focus {
                outline: none;
                border-color: #2563eb;
                box-shadow: 0 0 0 3px rgba(37, 99, 235, 0.1);
            }

            .btn {
                display: inline-block;
                padding: 8px 18px;
                background: #2563eb;
                color: #fff;
                border: none;
                border-radius: 6px;
                cursor: pointer;
                font-size: 0.95rem;
                font-family: inherit;
                transition: background 0.2s;
            }

            .btn:hover {
                background: #1d4ed8;
            }

            .btn-danger {
                background: #dc2626;
            }

            .btn-danger:hover {
                background: #b91c1c;
            }

            .btn-success {
                background: #16a34a;
            }

            .btn-success:hover {
                background: #15803d;
            }

            table {
                width: 100%;
                border-collapse: collapse;
                margin-top: 15px;
            }

            th,
            td {
                padding: 10px 14px;
                text-align: left;
                border-bottom: 1px solid #e5e7eb;
            }

            th {
                background: #f8fafc;
                font-weight: 600;
                color: #475569;
            }

            tr:hover {
                background: #f8fafc;
            }

            .alert {
                padding: 12px 16px;
                border-radius: 6px;
                margin-bottom: 20px;
            }

            .alert-success {
                background: #dcfce7;
                color: #166534;
            }

            .alert-error {
                background: #fef2f2;
                color: #991b1b;
            }

            .form-group {
                margin-bottom: 15px;
            }

            .form-group label {
                display: block;
                margin-bottom: 5px;
                font-weight: 600;
                color: #374151;
            }

            .form-inline {
                display: flex;
                gap: 10px;
                align-items: center;
                flex-wrap: wrap;
            }
        </style>
    </head>

    <body>
        <nav class="sidebar">
            <h3>🔧 CMS Admin</h3>
            <a href="index.php" <?php echo basename($_SERVER['SCRIPT_NAME']) === 'index.php' ? "class='active'" : ''; ?>>📊
                Dashboard</a>

            <?php if (is_admin()): ?>
                <a href="posts.php" <?php echo basename($_SERVER['SCRIPT_NAME']) === 'posts.php' ? "class='active'" : ''; ?>>📝
                    Tartalom</a>
                <a href="categories.php" <?php echo basename($_SERVER['SCRIPT_NAME']) === 'categories.php' ? "class='active'" : ''; ?>>🏷️ Kategóriák</a>
                <a href="media.php" <?php echo basename($_SERVER['SCRIPT_NAME']) === 'media.php' ? "class='active'" : ''; ?>>🖼️
                    Média</a>
                <a href="galleries.php" <?php echo basename($_SERVER['SCRIPT_NAME']) === 'galleries.php' ? "class='active'" : ''; ?>>🖼️ Galériák</a>
            <?php endif; ?>

            <?php if (is_super_admin()): ?>
                <a href="menu.php" <?php echo basename($_SERVER['SCRIPT_NAME']) === 'menu.php' ? "class='active'" : ''; ?>>📋
                    Menü</a>
                <div style="border-top: 1px solid #334155; margin: 15px 0;"></div>
                <a href="settings.php" <?php echo basename($_SERVER['SCRIPT_NAME']) === 'settings.php' ? "class='active'" : ''; ?>>⚙️ Beállítások</a>
                <a href="backups.php" <?php echo basename($_SERVER['SCRIPT_NAME']) === 'backups.php' ? "class='active'" : ''; ?>>📦 Mentések</a>
                <a href="activity_log.php" <?php echo basename($_SERVER['SCRIPT_NAME']) === 'activity_log.php' ? "class='active'" : ''; ?>>📋 Napló</a>
                <a href="users.php" <?php echo basename($_SERVER['SCRIPT_NAME']) === 'users.php' ? "class='active'" : ''; ?>>👥
                    Felhasználók</a>
            <?php endif; ?>

            <?php if (!is_super_admin() && !is_admin()): ?>
                <div style="border-top: 1px solid #334155; margin: 15px 0;"></div>
            <?php endif; ?>

            <a href="profile.php" <?php echo basename($_SERVER['SCRIPT_NAME']) === 'profile.php' ? "class='active'" : ''; ?>>👤 Profil</a>
            <a href="index.php?action=logout" class="logout">🚪 Kijelentkezés</a>
        </nav>
        <main class="content">
            <!-- Tetejére tapadó action bar -->
            <div
                style="position: sticky; top: 0; z-index: 999; background: #fff; padding: 15px 40px; margin: 0 -40px 30px -40px; border-bottom: 1px solid #e5e7eb; display: flex; justify-content: space-between; align-items: center; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.05);">
                <div style="display: flex; align-items: center; gap: 15px;">
                    <span style="font-weight: 600; color: #1e293b; font-size: 1.05rem;">👋 Üdv,
                        <?php echo htmlspecialchars($_SESSION['admin_user'] ?? 'Admin'); ?>!</span>
                    <?php if (!empty($topBar['view_link'])): ?>
                        <div style="width: 1px; height: 20px; background: #e5e7eb;"></div>
                        <a href="<?php echo htmlspecialchars($topBar['view_link']); ?>" target="_blank"
                            style="color: #3b82f6; text-decoration: none; font-size: 0.95rem; font-weight: 500;">👁️ Az oldal
                            megtekintése</a>
                    <?php endif; ?>
                </div>
                <div style="display: flex; gap: 10px; align-items: center;">
                    <?php echo $topBar['actions_html'] ?? ''; ?>
                </div>
            </div>

            <h2>
                <?php echo htmlspecialchars($pageTitle); ?>
            </h2>
            <?php
}

function admin_footer(): void
{
    ?>
        </main>
    </body>

    </html>
    <?php
}
