</div><!-- /.content -->
<footer>
    <div class="container">
        <p>
            <?php echo htmlspecialchars($settings['design']['footer_text'] ?? '© ' . date('Y')); ?>
        </p>
    </div>
</footer>
<script src="https://cdnjs.cloudflare.com/ajax/libs/fslightbox/3.4.1/index.min.js"></script>
</body>

</html>