<?php
// Kérlek, győződj meg róla, hogy a PHPMailer telepítve van (pl. composer require phpmailer/phpmailer)
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

// Ha Composer-t használsz, uncommenteld a következő sort:
// require 'vendor/autoload.php';

// Ha manuálisan töltötted le a PHPMailer-t, uncommenteld és módosítsd az útvonalakat:
/*
require 'path/to/PHPMailer/src/Exception.php';
require 'path/to/PHPMailer/src/PHPMailer.php';
require 'path/to/PHPMailer/src/SMTP.php';
*/

$mail = new PHPMailer(true);

try {
    // ------------------- SERVER BEÁLLÍTÁSOK -------------------
    $mail->SMTPDebug = 2;                      // Debug infók megjelenítése (0 = kikapcsolva, 1 = kliens, 2 = kliens és szerver)
    $mail->isSMTP();                           // SMTP protokoll használata

    $mail->Host = 'mail.privateemail.com'; // SMTP szerver címe

    $mail->SMTPAuth = true;                  // SMTP hitelesítés bekapcsolása (SPA kikapcsolva, ez alapértelmezett a PHPMailer-ben)
    $mail->Username = 'info@qfxdesign.hu';     // A fiókod / felhasználóneved
    $mail->Password = '680817-Aa';           // A megadott jelszó
    // SSL használata (465)
    // SSL használata (465) be volt kapcsolva, most kikapcsoljuk
    // $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS; // SSL titkosítás
    // $mail->Port = 465;                         // SSL port

    // -- Ha a TLS / STARTTLS-t szeretnéd használni az 587-es porton, akkor a fenti kettőt kommentezd ki, és ezt használd: --
    // -- Ha a TLS / STARTTLS-t szeretnéd használni az 587-es porton, akkor a fenti kettőt kommentezd ki, és ezt használd: --
    $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
    $mail->Port = 587;

    // ------------------- EMAIL TARTALMA -------------------
    $mail->setFrom('info@qfxdesign.hu', 'Teszt Feladó');
    $mail->addAddress('kufa.andras@gmail.com', 'Teszt Címzett'); // Ide megy a levél (küldheted magadnak tesztelésre)

    $mail->isHTML(true);                                  // HTML formátum
    $mail->Subject = 'Sikeres SMTP Teszt - privateemail.com';
    $mail->Body = '<b>Gratulálok!</b><br>Az új SMTP konfiguráció (mail.privateemail.com, 465 SSL) sikeresen működik.';
    $mail->AltBody = 'Gratulálok! Az új SMTP konfiguráció (mail.privateemail.com, 465 SSL) sikeresen működik.';

    $mail->send();
    echo "<br><b style='color:green;'>Siker: Az email elküldve!</b>";
} catch (Exception $e) {
    echo "<br><b style='color:red;'>Hiba az email küldése során. Részletek: {$mail->ErrorInfo}</b>";
}
