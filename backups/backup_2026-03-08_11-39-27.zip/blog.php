<?php
/**
 * Blog lista – Bejegyzések megjelenítése Perspective designnal
 */
require_once 'config.php';
require_once 'core/UrlHelper.php';
require_once 'core/functions.php';

// ---------- Beállítások ----------
$settings = [];
$settingsQuery = $db->query("SELECT * FROM settings");
while ($row = $settingsQuery->fetch()) {
    $settings[$row['setting_key']] = json_decode($row['setting_value'], true);
}

// ---------- Lapozó ----------
$perPage = 6;
$currentPage = max(1, (int) ($_GET['p'] ?? 1));
$offset = ($currentPage - 1) * $perPage;

// ---------- Kategória szűrő ----------
$catSlug = $_GET['cat'] ?? '';
$catInfo = null;
$whereExtra = '';
$params = [];

if ($catSlug) {
    $catStmt = $db->prepare("SELECT * FROM categories WHERE slug = ?");
    $catStmt->execute([$catSlug]);
    $catInfo = $catStmt->fetch();
    if ($catInfo) {
        $whereExtra = " AND p.id IN (SELECT post_id FROM post_categories WHERE category_id = ?)";
        $params[] = $catInfo['id'];
    }
}

// ---------- Bejegyzések lekérdezés ----------
$countSql = "SELECT COUNT(*) FROM posts p WHERE p.post_type = 'post' AND p.status = 'published' AND p.deleted_at IS NULL" . $whereExtra;
$countStmt = $db->prepare($countSql);
$countStmt->execute($params);
$totalPosts = $countStmt->fetchColumn();
$totalPages = max(1, ceil($totalPosts / $perPage));

$sql = "SELECT p.* FROM posts p WHERE p.post_type = 'post' AND p.status = 'published' AND p.deleted_at IS NULL" . $whereExtra . " ORDER BY p.id DESC LIMIT $perPage OFFSET $offset";
$stmt = $db->prepare($sql);
$stmt->execute($params);
$posts = $stmt->fetchAll();

// ---------- Kategóriák ----------
$categories = $db->query("SELECT c.*, (SELECT COUNT(*) FROM post_categories pc JOIN posts p2 ON pc.post_id = p2.id WHERE pc.category_id = c.id AND p2.status = 'published' AND p2.post_type = 'post' AND p2.deleted_at IS NULL) as post_count FROM categories c ORDER BY c.name")->fetchAll();

// ---------- Helper ----------
function get_category_tag_class_blog($categoryName) {
    $name = mb_strtolower($categoryName);
    $map = [
        'financ' => 'tag-financing', 'pénz' => 'tag-financing', 'gazdaság' => 'tag-financing',
        'lifestyle' => 'tag-lifestyle', 'élet' => 'tag-lifestyle',
        'community' => 'tag-community', 'közösség' => 'tag-community',
        'wellness' => 'tag-wellness', 'egészség' => 'tag-wellness',
        'travel' => 'tag-travel', 'utazás' => 'tag-travel',
        'creativ' => 'tag-creativity', 'kreativ' => 'tag-creativity', 'művész' => 'tag-creativity',
        'growth' => 'tag-growth', 'fejlőd' => 'tag-growth', 'tanul' => 'tag-growth',
    ];
    foreach ($map as $key => $class) {
        if (strpos($name, $key) !== false) return $class;
    }
    $colors = ['tag-financing', 'tag-lifestyle', 'tag-community', 'tag-wellness', 'tag-travel', 'tag-creativity', 'tag-growth'];
    return $colors[crc32($categoryName) % count($colors)];
}

// Dummy page for header SEO
$page = [
    'title' => $catInfo ? $catInfo['name'] : 'Blog',
    'meta_title' => $catInfo ? $catInfo['name'] . ' – Blog' : 'Blog',
    'meta_description' => $catInfo ? ($catInfo['description'] ?? '') : ($settings['site_info']['description'] ?? ''),
];

include 'theme/header.php';
?>

<div class="container animate-fade-in">
    <!-- Blog Hero -->
    <div class="blog-hero">
        <h1><?php echo htmlspecialchars($catInfo ? $catInfo['name'] : 'Blog'); ?></h1>
        <?php if ($catInfo && !empty($catInfo['description'])): ?>
            <p><?php echo htmlspecialchars($catInfo['description']); ?></p>
        <?php else: ?>
            <p>Fedezd fel legújabb cikkeinket és írásainkat.</p>
        <?php endif; ?>
    </div>

    <!-- Category Filter -->
    <?php if (!empty($categories)): ?>
    <div class="category-filter">
        <a href="<?php echo UrlHelper::link('blog'); ?>" class="category-pill <?php echo !$catSlug ? 'active' : ''; ?>">
            Összes
        </a>
        <?php foreach ($categories as $cat): ?>
            <?php if ($cat['post_count'] > 0): ?>
                <a href="<?php echo UrlHelper::link('blog?cat=' . urlencode($cat['slug'])); ?>"
                   class="category-pill <?php echo $catSlug === $cat['slug'] ? 'active' : ''; ?>">
                    <?php echo htmlspecialchars($cat['name']); ?> (<?php echo $cat['post_count']; ?>)
                </a>
            <?php endif; ?>
        <?php endforeach; ?>
    </div>
    <?php endif; ?>

    <!-- Articles -->
    <?php if (empty($posts)): ?>
        <div class="empty-state">
            <p>Nincs bejegyzés<?php echo $catInfo ? ' ebben a kategóriában' : ''; ?>.</p>
        </div>
    <?php else: ?>
        <div class="article-grid">
            <?php foreach ($posts as $i => $post):
                $postCats = $db->prepare("SELECT c.name, c.slug FROM categories c JOIN post_categories pc ON c.id = pc.category_id WHERE pc.post_id = ?");
                $postCats->execute([$post['id']]);
                $postCatList = $postCats->fetchAll();
                $firstCat = $postCatList[0] ?? null;
            ?>
                <a href="<?php echo UrlHelper::link($post['slug']); ?>" class="article-card" data-animate="slide-up" style="animation-delay: <?php echo ($i * 0.1); ?>s">
                    <div class="article-card-image">
                        <?php if (!empty($post['featured_image'])): ?>
                            <img src="<?php echo UrlHelper::asset($post['featured_image']); ?>" alt="<?php echo htmlspecialchars($post['title']); ?>">
                        <?php else: ?>
                            <div style="width:100%;height:100%;background:linear-gradient(135deg, var(--secondary), var(--accent));"></div>
                        <?php endif; ?>
                        <div class="gradient-overlay"></div>
                    </div>
                    <div class="article-card-content">
                        <div class="article-card-top">
                            <?php if ($firstCat): ?>
                                <span class="category-tag <?php echo get_category_tag_class_blog($firstCat['name']); ?>"><?php echo htmlspecialchars($firstCat['name']); ?></span>
                            <?php else: ?>
                                <span></span>
                            <?php endif; ?>
                            <span class="date-badge"><?php echo date('Y.m.d', strtotime($post['created_at'] ?? $post['updated_at'] ?? 'now')); ?></span>
                        </div>
                        <div class="article-card-bottom">
                            <h3 class="article-card-title"><?php echo htmlspecialchars($post['title']); ?></h3>
                            <span class="floating-button">
                                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="7" y1="17" x2="17" y2="7"/><polyline points="7 7 17 7 17 17"/></svg>
                            </span>
                        </div>
                    </div>
                </a>
            <?php endforeach; ?>
        </div>

        <!-- Pagination -->
        <?php if ($totalPages > 1): ?>
        <div class="pagination">
            <?php for ($i = 1; $i <= $totalPages; $i++): ?>
                <?php if ($i === $currentPage): ?>
                    <span class="active"><?php echo $i; ?></span>
                <?php else: ?>
                    <a href="<?php echo UrlHelper::link('blog?p=' . $i . ($catSlug ? '&cat=' . urlencode($catSlug) : '')); ?>">
                        <?php echo $i; ?>
                    </a>
                <?php endif; ?>
            <?php endfor; ?>
        </div>
        <?php endif; ?>
    <?php endif; ?>
</div>

<?php include 'theme/footer.php'; ?>
