/* Perspective Theme - JavaScript */
(function() {
    'use strict';

    var html = document.documentElement;
    var THEME_KEY = 'perspective-theme';

    function getTheme() {
        var saved = localStorage.getItem(THEME_KEY);
        if (saved) return saved;
        return window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
    }

    function applyTheme(theme) {
        html.classList.toggle('dark', theme === 'dark');
        document.querySelectorAll('.theme-icon-moon').forEach(function(el) { el.style.display = theme === 'dark' ? 'none' : 'block'; });
        document.querySelectorAll('.theme-icon-sun').forEach(function(el) { el.style.display = theme === 'dark' ? 'block' : 'none'; });
    }

    function toggleTheme() {
        var next = html.classList.contains('dark') ? 'light' : 'dark';
        localStorage.setItem(THEME_KEY, next);
        applyTheme(next);
    }

    function init() {
        applyTheme(getTheme());

        document.querySelectorAll('.theme-toggle').forEach(function(btn) {
            btn.addEventListener('click', toggleTheme);
        });

        /* Mobile Menu */
        var menuBtn = document.querySelector('.mobile-menu-btn');
        var mobileNav = document.querySelector('.mobile-nav');
        if (menuBtn && mobileNav) {
            menuBtn.addEventListener('click', function() {
                var isOpen = mobileNav.classList.toggle('open');
                var iconMenu = menuBtn.querySelector('.icon-menu');
                var iconX = menuBtn.querySelector('.icon-x');
                if (iconMenu) iconMenu.style.display = isOpen ? 'none' : 'block';
                if (iconX) iconX.style.display = isOpen ? 'block' : 'none';
            });
        }

        /* Scroll Animations */
        var animatedEls = document.querySelectorAll('[data-animate]');
        if (animatedEls.length && 'IntersectionObserver' in window) {
            var observer = new IntersectionObserver(function(entries) {
                entries.forEach(function(entry) {
                    if (entry.isIntersecting) {
                        entry.target.classList.add('is-visible');
                        observer.unobserve(entry.target);
                    }
                });
            }, { threshold: 0.1, rootMargin: '0px 0px -50px 0px' });

            animatedEls.forEach(function(el) { observer.observe(el); });
        }

        /* Share Link Copy */
        document.querySelectorAll('.share-copy-btn').forEach(function(btn) {
            btn.addEventListener('click', function(e) {
                e.preventDefault();
                navigator.clipboard.writeText(window.location.href).then(function() {
                    var orig = btn.innerHTML;
                    btn.innerHTML = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="20 6 9 17 4 12"/></svg>';
                    setTimeout(function() { btn.innerHTML = orig; }, 2000);
                });
            });
        });
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }
})();
