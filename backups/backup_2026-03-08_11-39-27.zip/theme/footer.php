</main>

<footer class="site-footer">
    <div class="container">
        <div class="footer-grid">
            <div class="footer-col">
                <h4 class="footer-heading"><?php echo htmlspecialchars($settings['footer']['col1_title'] ?? 'Rólunk'); ?></h4>
                <p style="font-size: 0.875rem; color: var(--muted-foreground); line-height: 1.7;">
                    <?php echo nl2br(htmlspecialchars($settings['footer']['col1_text'] ?? $settings['site_info']['description'] ?? '')); ?>
                </p>
            </div>

            <div class="footer-col">
                <h4 class="footer-heading"><?php echo htmlspecialchars($settings['footer']['col2_title'] ?? 'Navigáció'); ?></h4>
                <ul>
                    <li><a href="<?php echo UrlHelper::link(); ?>">Kezdőlap</a></li>
                    <?php
                    $footerMenuItems = $db->query("SELECT * FROM menus ORDER BY sort_order ASC")->fetchAll();
                    foreach ($footerMenuItems as $item):
                        $url = (strpos($item['url'], 'http') === 0) ? $item['url'] : UrlHelper::link($item['url']);
                    ?>
                        <li><a href="<?php echo htmlspecialchars($url); ?>"><?php echo htmlspecialchars($item['label']); ?></a></li>
                    <?php endforeach; ?>
                    <li><a href="<?php echo UrlHelper::link('blog'); ?>">Blog</a></li>
                </ul>
            </div>

            <div class="footer-col">
                <h4 class="footer-heading">Kategóriák</h4>
                <ul>
                    <?php
                    $footerCats = $db->query("SELECT name, slug FROM categories ORDER BY sort_order ASC, name ASC LIMIT 8")->fetchAll();
                    foreach ($footerCats as $cat):
                    ?>
                        <li><a href="<?php echo UrlHelper::link('blog?cat=' . urlencode($cat['slug'])); ?>"><?php echo htmlspecialchars($cat['name']); ?></a></li>
                    <?php endforeach; ?>
                </ul>
            </div>

            <div class="footer-col">
                <h4 class="footer-heading"><?php echo htmlspecialchars($settings['footer']['col3_title'] ?? 'Kapcsolat'); ?></h4>
                <ul style="color: var(--muted-foreground); font-size: 0.875rem;">
                    <?php if (!empty($settings['footer']['col3_text'] ?? '')): ?>
                        <li><?php echo nl2br(htmlspecialchars($settings['footer']['col3_text'])); ?></li>
                    <?php else: ?>
                        <li>info@<?php echo htmlspecialchars(str_replace(['http://', 'https://', 'www.'], '', $settings['site_info']['name'] ?? 'example.com')); ?></li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>

        <div class="footer-bottom">
            <p>&copy; <?php echo date('Y'); ?> <?php echo htmlspecialchars($settings['site_info']['name'] ?? 'Perspective'); ?>. Minden jog fenntartva.</p>
        </div>
    </div>
</footer>

<script src="https://cdnjs.cloudflare.com/ajax/libs/fslightbox/3.4.1/index.min.js"></script>
<script src="<?php echo UrlHelper::themeAsset('perspective.js'); ?>" defer></script>
</body>
</html>
