<?php
require_once __DIR__ . '/../core/functions.php';
require_once __DIR__ . '/../core/UrlHelper.php';

// Menu items
$menuItems = $db->query("SELECT * FROM menus ORDER BY sort_order ASC")->fetchAll();

// Categories for mobile nav
$navCategories = $db->query("SELECT name, slug FROM categories ORDER BY sort_order ASC, name ASC")->fetchAll();

// Site name initial for logo fallback
$siteName = $settings['site_info']['name'] ?? 'Perspective';
$siteInitial = mb_substr($siteName, 0, 1);
?>
<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover">
    <?php render_seo_tags($page, $settings); ?>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&family=Merriweather:wght@400;700;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo UrlHelper::themeAsset('style.css'); ?>">
    <script>
    (function(){var t=localStorage.getItem('perspective-theme');if(!t)t=window.matchMedia('(prefers-color-scheme:dark)').matches?'dark':'light';if(t==='dark')document.documentElement.classList.add('dark');})();
    </script>
</head>
<body>

<header class="sticky-header">
    <div class="container">
        <div class="pill-nav">
            <!-- Logo -->
            <a href="<?php echo UrlHelper::link(); ?>" class="nav-logo">
                <?php if (!empty($settings['site_info']['logo'])): ?>
                    <img src="<?php echo UrlHelper::asset($settings['site_info']['logo']); ?>" alt="<?php echo htmlspecialchars($siteName); ?>" class="nav-logo-img">
                <?php else: ?>
                    <span class="nav-logo-icon"><?php echo htmlspecialchars($siteInitial); ?></span>
                <?php endif; ?>
                <span class="nav-logo-text"><?php echo htmlspecialchars($siteName); ?></span>
            </a>

            <!-- Desktop Navigation -->
            <nav class="desktop-nav">
                <a href="<?php echo UrlHelper::link(); ?>" class="nav-pill-link">Kezdőlap</a>
                <?php foreach ($menuItems as $item):
                    $url = (strpos($item['url'], 'http') === 0) ? $item['url'] : UrlHelper::link($item['url']);
                ?>
                    <a href="<?php echo htmlspecialchars($url); ?>" class="nav-pill-link"><?php echo htmlspecialchars($item['label']); ?></a>
                <?php endforeach; ?>
                <a href="<?php echo UrlHelper::link('blog'); ?>" class="nav-pill-link">Blog</a>
            </nav>

            <!-- Actions -->
            <div class="nav-actions">
                <!-- Dark mode toggle -->
                <button class="btn-icon theme-toggle" type="button" aria-label="Téma váltás">
                    <svg class="theme-icon-moon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/></svg>
                    <svg class="theme-icon-sun" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="display:none"><circle cx="12" cy="12" r="5"/><line x1="12" y1="1" x2="12" y2="3"/><line x1="12" y1="21" x2="12" y2="23"/><line x1="4.22" y1="4.22" x2="5.64" y2="5.64"/><line x1="18.36" y1="18.36" x2="19.78" y2="19.78"/><line x1="1" y1="12" x2="3" y2="12"/><line x1="21" y1="12" x2="23" y2="12"/><line x1="4.22" y1="19.78" x2="5.64" y2="18.36"/><line x1="18.36" y1="5.64" x2="19.78" y2="4.22"/></svg>
                </button>

                <!-- Mobile menu button -->
                <button class="btn-icon mobile-menu-btn" type="button" aria-label="Menü">
                    <svg class="icon-menu" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="4" y1="6" x2="20" y2="6"/><line x1="4" y1="12" x2="20" y2="12"/><line x1="4" y1="18" x2="20" y2="18"/></svg>
                    <svg class="icon-x" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="display:none"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
                </button>
            </div>
        </div>

        <!-- Mobile Navigation -->
        <nav class="mobile-nav">
            <a href="<?php echo UrlHelper::link(); ?>" class="nav-pill-link">Kezdőlap</a>
            <?php foreach ($menuItems as $item):
                $url = (strpos($item['url'], 'http') === 0) ? $item['url'] : UrlHelper::link($item['url']);
            ?>
                <a href="<?php echo htmlspecialchars($url); ?>" class="nav-pill-link"><?php echo htmlspecialchars($item['label']); ?></a>
            <?php endforeach; ?>
            <a href="<?php echo UrlHelper::link('blog'); ?>" class="nav-pill-link">Blog</a>
        </nav>
    </div>
</header>

<main>
