-- CMS Adatbázis Biztonsági Mentés
-- Ideje: 2026-03-07 13:37:20

SET FOREIGN_KEY_CHECKS = 0;

DROP TABLE IF EXISTS `activity_log`;
CREATE TABLE `activity_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `username` varchar(100) DEFAULT NULL,
  `action` varchar(50) NOT NULL,
  `target_type` varchar(50) DEFAULT NULL,
  `target_id` int(11) DEFAULT NULL,
  `target_title` varchar(255) DEFAULT NULL,
  `details` text DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_created` (`created_at`),
  KEY `idx_user` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `activity_log` (`id`, `user_id`, `username`, `action`, `target_type`, `target_id`, `target_title`, `details`, `ip_address`, `created_at`) VALUES ('1', '1', 'admin', 'create', 'user', '2', 'zizike', NULL, '::1', '2026-03-07 12:19:53');
INSERT INTO `activity_log` (`id`, `user_id`, `username`, `action`, `target_type`, `target_id`, `target_title`, `details`, `ip_address`, `created_at`) VALUES ('2', '1', 'admin', 'update', 'category', '1', 'hírek', NULL, '::1', '2026-03-07 12:24:02');
INSERT INTO `activity_log` (`id`, `user_id`, `username`, `action`, `target_type`, `target_id`, `target_title`, `details`, `ip_address`, `created_at`) VALUES ('3', '1', 'admin', 'create', 'post', '4', 'Valami', NULL, '::1', '2026-03-07 12:25:10');
INSERT INTO `activity_log` (`id`, `user_id`, `username`, `action`, `target_type`, `target_id`, `target_title`, `details`, `ip_address`, `created_at`) VALUES ('4', '1', 'admin', 'create', 'post', '8', 'Valami', NULL, '::1', '2026-03-07 12:27:19');
INSERT INTO `activity_log` (`id`, `user_id`, `username`, `action`, `target_type`, `target_id`, `target_title`, `details`, `ip_address`, `created_at`) VALUES ('5', '1', 'admin', 'create', 'post', '9', 'dsq', NULL, '::1', '2026-03-07 12:27:37');
INSERT INTO `activity_log` (`id`, `user_id`, `username`, `action`, `target_type`, `target_id`, `target_title`, `details`, `ip_address`, `created_at`) VALUES ('6', '1', 'admin', 'update', 'settings', NULL, 'Beállítások', NULL, '::1', '2026-03-07 12:33:29');
INSERT INTO `activity_log` (`id`, `user_id`, `username`, `action`, `target_type`, `target_id`, `target_title`, `details`, `ip_address`, `created_at`) VALUES ('7', '1', 'admin', 'update', 'settings', NULL, 'Beállítások', NULL, '::1', '2026-03-07 12:33:35');
INSERT INTO `activity_log` (`id`, `user_id`, `username`, `action`, `target_type`, `target_id`, `target_title`, `details`, `ip_address`, `created_at`) VALUES ('8', '1', 'admin', 'update', 'page', '10', 'Kiscicák születtek Székesfehérváron: Egy édes család története', NULL, '::1', '2026-03-07 12:38:18');
INSERT INTO `activity_log` (`id`, `user_id`, `username`, `action`, `target_type`, `target_id`, `target_title`, `details`, `ip_address`, `created_at`) VALUES ('9', '1', 'admin', 'create', 'media', '2', 'avaregetes.jpg', NULL, '::1', '2026-03-07 12:51:05');
INSERT INTO `activity_log` (`id`, `user_id`, `username`, `action`, `target_type`, `target_id`, `target_title`, `details`, `ip_address`, `created_at`) VALUES ('10', '1', 'admin', 'create', 'media', '3', 'adventi.jpg', NULL, '::1', '2026-03-07 12:51:12');
INSERT INTO `activity_log` (`id`, `user_id`, `username`, `action`, `target_type`, `target_id`, `target_title`, `details`, `ip_address`, `created_at`) VALUES ('11', '1', 'admin', 'create', 'page', '12', 'Harckocsik a Teve Utcai Óvodában: Játék, Fantázia és Tanulás', NULL, '::1', '2026-03-07 13:06:24');
INSERT INTO `activity_log` (`id`, `user_id`, `username`, `action`, `target_type`, `target_id`, `target_title`, `details`, `ip_address`, `created_at`) VALUES ('12', '1', 'admin', 'update', 'post', '12', 'Harckocsik a Teve Utcai Óvodában: Játék, Fantázia és Tanulás', NULL, '::1', '2026-03-07 13:06:48');
INSERT INTO `activity_log` (`id`, `user_id`, `username`, `action`, `target_type`, `target_id`, `target_title`, `details`, `ip_address`, `created_at`) VALUES ('13', '1', 'admin', 'update', 'post', '11', 'A túlérett sajt robbanása: Mi történik, ha a sajt túl sokáig érlelődik?', NULL, '::1', '2026-03-07 13:06:59');
INSERT INTO `activity_log` (`id`, `user_id`, `username`, `action`, `target_type`, `target_id`, `target_title`, `details`, `ip_address`, `created_at`) VALUES ('14', '1', 'admin', 'update', 'post', '10', 'Kiscicák születtek Székesfehérváron: Egy édes család története', NULL, '::1', '2026-03-07 13:07:24');
INSERT INTO `activity_log` (`id`, `user_id`, `username`, `action`, `target_type`, `target_id`, `target_title`, `details`, `ip_address`, `created_at`) VALUES ('15', '1', 'admin', 'create', 'menu', '6', 'hírek', NULL, '::1', '2026-03-07 13:07:40');
INSERT INTO `activity_log` (`id`, `user_id`, `username`, `action`, `target_type`, `target_id`, `target_title`, `details`, `ip_address`, `created_at`) VALUES ('16', '1', 'admin', 'create', 'backup', '0', 'backup_2026-03-07_13-22-36.zip', NULL, '::1', '2026-03-07 13:22:37');
INSERT INTO `activity_log` (`id`, `user_id`, `username`, `action`, `target_type`, `target_id`, `target_title`, `details`, `ip_address`, `created_at`) VALUES ('17', '1', 'admin', 'create', 'backup', '0', 'backup_2026-03-07_13-30-07.zip', NULL, '::1', '2026-03-07 13:30:07');
INSERT INTO `activity_log` (`id`, `user_id`, `username`, `action`, `target_type`, `target_id`, `target_title`, `details`, `ip_address`, `created_at`) VALUES ('18', '1', 'admin', 'create', 'backup', '0', 'backup_2026-03-07_13-31-05.zip', NULL, '::1', '2026-03-07 13:31:05');
INSERT INTO `activity_log` (`id`, `user_id`, `username`, `action`, `target_type`, `target_id`, `target_title`, `details`, `ip_address`, `created_at`) VALUES ('19', '1', 'admin', 'delete', 'backup', '0', 'backup_2026-03-07_13-31-05.zip', NULL, '::1', '2026-03-07 13:31:08');
INSERT INTO `activity_log` (`id`, `user_id`, `username`, `action`, `target_type`, `target_id`, `target_title`, `details`, `ip_address`, `created_at`) VALUES ('20', '1', 'admin', 'create', 'backup', '0', 'backup_2026-03-07_13-32-15.zip', NULL, '::1', '2026-03-07 13:32:15');
INSERT INTO `activity_log` (`id`, `user_id`, `username`, `action`, `target_type`, `target_id`, `target_title`, `details`, `ip_address`, `created_at`) VALUES ('21', '1', 'admin', 'delete', 'backup', '0', 'backup_2026-03-07_13-32-15.zip', NULL, '::1', '2026-03-07 13:32:19');
INSERT INTO `activity_log` (`id`, `user_id`, `username`, `action`, `target_type`, `target_id`, `target_title`, `details`, `ip_address`, `created_at`) VALUES ('22', '1', 'admin', 'delete', 'backup', '0', 'backup_2026-03-07_13-30-07.zip', NULL, '::1', '2026-03-07 13:37:14');
INSERT INTO `activity_log` (`id`, `user_id`, `username`, `action`, `target_type`, `target_id`, `target_title`, `details`, `ip_address`, `created_at`) VALUES ('23', '1', 'admin', 'delete', 'backup', '0', 'backup_2026-03-07_13-22-36.zip', NULL, '::1', '2026-03-07 13:37:16');

DROP TABLE IF EXISTS `categories`;
CREATE TABLE `categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `slug` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `sort_order` int(11) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `slug` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `categories` (`id`, `name`, `slug`, `description`, `sort_order`, `created_at`) VALUES ('1', 'hírek', 'hirek', 'qsq', '1', '2026-03-06 17:04:42');

DROP TABLE IF EXISTS `media`;
CREATE TABLE `media` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `filename` varchar(255) DEFAULT NULL,
  `filepath` varchar(255) DEFAULT NULL,
  `alt_text` varchar(255) DEFAULT NULL,
  `caption` text DEFAULT NULL,
  `file_size` int(11) DEFAULT NULL,
  `mime_type` varchar(100) DEFAULT NULL,
  `width` int(11) DEFAULT NULL,
  `height` int(11) DEFAULT NULL,
  `sizes` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `media` (`id`, `filename`, `filepath`, `alt_text`, `caption`, `file_size`, `mime_type`, `width`, `height`, `sizes`) VALUES ('1', 'ellenorzes.jpg', '2026/03/1772812649_42dbcbcc.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `media` (`id`, `filename`, `filepath`, `alt_text`, `caption`, `file_size`, `mime_type`, `width`, `height`, `sizes`) VALUES ('2', 'avaregetes.jpg', '2026/03/1772884265_db84cc34.jpg', NULL, NULL, '84764', 'image/jpeg', '1051', '731', '{\"original\":{\"width\":1051,\"height\":731,\"path\":\"1772884265_db84cc34.jpg\"},\"thumbnail\":{\"width\":150,\"height\":104,\"path\":\"1772884265_db84cc34-thumbnail.jpeg\"},\"medium\":{\"width\":640,\"height\":445,\"path\":\"1772884265_db84cc34-medium.jpeg\"},\"webp\":{\"original\":\"1772884265_db84cc34.webp\",\"thumbnail\":\"1772884265_db84cc34-thumbnail.webp\",\"medium\":\"1772884265_db84cc34-medium.webp\"}}');
INSERT INTO `media` (`id`, `filename`, `filepath`, `alt_text`, `caption`, `file_size`, `mime_type`, `width`, `height`, `sizes`) VALUES ('3', 'adventi.jpg', '2026/03/1772884272_d39a13ca.jpg', NULL, NULL, '68989', 'image/jpeg', '800', '600', '{\"original\":{\"width\":800,\"height\":600,\"path\":\"1772884272_d39a13ca.jpg\"},\"thumbnail\":{\"width\":150,\"height\":112,\"path\":\"1772884272_d39a13ca-thumbnail.jpeg\"},\"medium\":{\"width\":640,\"height\":480,\"path\":\"1772884272_d39a13ca-medium.jpeg\"},\"webp\":{\"original\":\"1772884272_d39a13ca.webp\",\"thumbnail\":\"1772884272_d39a13ca-thumbnail.webp\",\"medium\":\"1772884272_d39a13ca-medium.webp\"}}');

DROP TABLE IF EXISTS `menus`;
CREATE TABLE `menus` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `label` varchar(100) DEFAULT NULL,
  `url` varchar(255) DEFAULT NULL,
  `sort_order` int(11) DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `menus` (`id`, `label`, `url`, `sort_order`) VALUES ('1', 'Első oldal', 'elso-oldal', '1');
INSERT INTO `menus` (`id`, `label`, `url`, `sort_order`) VALUES ('3', 'scscas', 'elso-oldal', '3');
INSERT INTO `menus` (`id`, `label`, `url`, `sort_order`) VALUES ('4', 'sdesdfdsf', 'sdesdfdsf', '4');
INSERT INTO `menus` (`id`, `label`, `url`, `sort_order`) VALUES ('5', 'sqsqsq', 'blog?cat=sqsqsq', '5');
INSERT INTO `menus` (`id`, `label`, `url`, `sort_order`) VALUES ('6', 'hírek', 'blog?cat=hirek', '6');

DROP TABLE IF EXISTS `post_categories`;
CREATE TABLE `post_categories` (
  `post_id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  PRIMARY KEY (`post_id`,`category_id`),
  KEY `category_id` (`category_id`),
  CONSTRAINT `post_categories_ibfk_1` FOREIGN KEY (`post_id`) REFERENCES `posts` (`id`) ON DELETE CASCADE,
  CONSTRAINT `post_categories_ibfk_2` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

DROP TABLE IF EXISTS `posts`;
CREATE TABLE `posts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) DEFAULT NULL,
  `slug` varchar(255) DEFAULT NULL,
  `content` text DEFAULT NULL,
  `status` varchar(20) DEFAULT 'published',
  `post_type` varchar(20) DEFAULT 'page',
  `meta_title` varchar(255) DEFAULT NULL,
  `meta_description` text DEFAULT NULL,
  `featured_image` varchar(255) DEFAULT NULL,
  `publish_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `slug` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `posts` (`id`, `title`, `slug`, `content`, `status`, `post_type`, `meta_title`, `meta_description`, `featured_image`, `publish_at`, `deleted_at`) VALUES ('1', 'Első oldal', 'elso-oldal', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.', 'published', 'page', '', '', '2026/03/1772812649_42dbcbcc.jpg', NULL, NULL);
INSERT INTO `posts` (`id`, `title`, `slug`, `content`, `status`, `post_type`, `meta_title`, `meta_description`, `featured_image`, `publish_at`, `deleted_at`) VALUES ('2', 'sdesdfdsf', 'sdesdfdsf', '<p>frggfdsfsdg</p>', 'published', 'page', '', '', '2026/03/1772812649_42dbcbcc.jpg', NULL, NULL);
INSERT INTO `posts` (`id`, `title`, `slug`, `content`, `status`, `post_type`, `meta_title`, `meta_description`, `featured_image`, `publish_at`, `deleted_at`) VALUES ('4', 'Valami', 'valami', '<p>dsdsdsd</p><p>sdsdsdsdsdsds</p>', 'published', 'post', '', '', '2026/03/1772812649_42dbcbcc.jpg', NULL, NULL);
INSERT INTO `posts` (`id`, `title`, `slug`, `content`, `status`, `post_type`, `meta_title`, `meta_description`, `featured_image`, `publish_at`, `deleted_at`) VALUES ('8', 'Valami', 'valami-2', '<p>dsdsdsd</p><p>sdsdsdsdsdsds</p>', 'published', 'post', '', '', NULL, NULL, NULL);
INSERT INTO `posts` (`id`, `title`, `slug`, `content`, `status`, `post_type`, `meta_title`, `meta_description`, `featured_image`, `publish_at`, `deleted_at`) VALUES ('9', 'dsq', 'daaa', '<p>ewewewewwsasasas</p><p><br></p><p>asasasa</p>', 'published', 'post', '', '', '2026/03/1772812649_42dbcbcc.jpg', NULL, NULL);
INSERT INTO `posts` (`id`, `title`, `slug`, `content`, `status`, `post_type`, `meta_title`, `meta_description`, `featured_image`, `publish_at`, `deleted_at`) VALUES ('10', 'Kiscicák születtek Székesfehérváron: Egy édes család története', 'kiscicak-szulettek-szekesfehervaron-egy-edes-csalad-tortenete', '<h2>Kiscic&aacute;k &eacute;rkeztek Sz&eacute;kesfeh&eacute;rv&aacute;ron</h2>\r\n<p>Sz&eacute;kesfeh&eacute;rv&aacute;ron egy meghat&oacute; esem&eacute;ny zajlott le, amikor egy macska csal&aacute;d &uacute;j tagokkal bőv&uuml;lt. A kiscic&aacute;k sz&uuml;let&eacute;se mindig k&uuml;l&ouml;nleges pillanat, &eacute;s ez a t&ouml;rt&eacute;net sem volt kiv&eacute;tel. A v&aacute;ros k&ouml;zpontj&aacute;ban, egy bar&aacute;ts&aacute;gos otthonban, egy anyamacska n&eacute;gy eg&eacute;szs&eacute;ges kiscic&aacute;t hozott a vil&aacute;gra.</p>\r\n<h3>Hogyan t&ouml;rt&eacute;nt a sz&uuml;let&eacute;s?</h3>\r\n<p>Az anyamacska, akit a gazd&aacute;i Cirminek h&iacute;vnak, gondosan elők&eacute;sz&iacute;tette mag&aacute;t a sz&uuml;l&eacute;sre. A gazd&aacute;k &eacute;szrevett&eacute;k, hogy nyugtalanabb &eacute;s biztons&aacute;gos helyet keres, &iacute;gy kialak&iacute;tottak neki egy k&eacute;nyelmes f&eacute;szkelőhelyet. A sz&uuml;l&eacute;s sim&aacute;n zajlott le, &eacute;s n&eacute;gy kis bundabog&aacute;r sz&uuml;letett eg&eacute;szs&eacute;gesen.</p>\r\n<h3>A kiscic&aacute;k jellemzői</h3>\r\n<p>A n&eacute;gy kiscica k&uuml;l&ouml;nb&ouml;ző sz&iacute;nű &eacute;s mint&aacute;zat&uacute;, ami m&eacute;g &eacute;rdekesebb&eacute; teszi a csal&aacute;dot. Itt van egy r&ouml;vid bemutat&aacute;suk:</p>\r\n<ul>\r\n<li>Egy fekete-feh&eacute;r tarka kiscica, aki a legk&iacute;v&aacute;ncsibb a csapatb&oacute;l.</li>\r\n<li>K&eacute;t sz&uuml;rke cs&iacute;kos kiscica, akik im&aacute;dnak egy&uuml;tt j&aacute;tszani.</li>\r\n<li>Egy narancss&aacute;rga kiscica, aki a legnyugodtabbnak tűnik.</li>\r\n</ul>\r\n<h2>Mi&eacute;rt fontos a felelős &aacute;llattart&aacute;s?</h2>\r\n<p>A kiscic&aacute;k sz&uuml;let&eacute;se eml&eacute;keztet minket a felelős &aacute;llattart&aacute;s jelentős&eacute;g&eacute;re. Itt van n&eacute;h&aacute;ny kulcsfontoss&aacute;g&uacute; pont:</p>\r\n<ul>\r\n<li>Az &aacute;llatok ivartalan&iacute;t&aacute;sa seg&iacute;t megelőzni a nem k&iacute;v&aacute;nt alomokat.</li>\r\n<li>Rendszeres &aacute;llatorvosi ellenőrz&eacute;sek biztos&iacute;tj&aacute;k az eg&eacute;szs&eacute;get.</li>\r\n<li>Megfelelő t&aacute;pl&aacute;l&eacute;k &eacute;s gondoskod&aacute;s elengedhetetlen a kiscic&aacute;k fejlőd&eacute;s&eacute;hez.</li>\r\n</ul>\r\n<h3>Hogyan seg&iacute;thetsz hasonl&oacute; helyzetekben?</h3>\r\n<p>Ha Sz&eacute;kesfeh&eacute;rv&aacute;ron vagy a k&ouml;rny&eacute;ken &eacute;lsz, &eacute;s szeretn&eacute;l seg&iacute;teni, fontos, hogy kapcsolatba l&eacute;pj helyi &aacute;llatv&eacute;dő szervezetekkel. Sok &ouml;nk&eacute;ntes munka &eacute;s t&aacute;mogat&aacute;sra van sz&uuml;ks&eacute;g, hogy a kiscic&aacute;k &eacute;s m&aacute;s &aacute;llatok biztons&aacute;gban legyenek.</p>\r\n<h2>&Ouml;r&ouml;m &eacute;s felelőss&eacute;g egy&uuml;tt</h2>\r\n<p>A kiscic&aacute;k sz&uuml;let&eacute;se Sz&eacute;kesfeh&eacute;rv&aacute;ron egy gy&ouml;ny&ouml;rű eml&eacute;keztető arra, hogy az &aacute;llatok szeretete &eacute;s gondoskod&aacute;s mennyi &ouml;r&ouml;met hozhat az &eacute;let&uuml;nkbe. Rem&eacute;lj&uuml;k, hogy ez a t&ouml;rt&eacute;net inspir&aacute;l m&aacute;sokat is a felelős &aacute;llattart&aacute;sra &eacute;s az &aacute;llatv&eacute;delem t&aacute;mogat&aacute;s&aacute;ra.</p>', 'published', 'post', '', '', NULL, NULL, NULL);
INSERT INTO `posts` (`id`, `title`, `slug`, `content`, `status`, `post_type`, `meta_title`, `meta_description`, `featured_image`, `publish_at`, `deleted_at`) VALUES ('11', 'A túlérett sajt robbanása: Mi történik, ha a sajt túl sokáig érlelődik?', 'a-tulerett-sajt-robbanasa-mi-tortenik-ha-a-sajt-tul-sokaig-erlelodik', '<h2>Bevezet&eacute;s: A sajt &eacute;letciklusa &eacute;s a t&uacute;l&eacute;retts&eacute;g</h2>\r\n<p>A sajtok, mint &eacute;lő term&eacute;kek, folyamatosan v&aacute;ltoznak az &eacute;rlel&eacute;s sor&aacute;n. De mi t&ouml;rt&eacute;nik, ha egy sajt t&uacute;l sok&aacute;ig &eacute;rlelődik? A \"t&uacute;l&eacute;rett sajt\" nem csak egy kifejez&eacute;s &ndash; n&eacute;ha val&oacute;di robban&aacute;ssal j&aacute;rhat! Ebben a cikkben megvizsg&aacute;ljuk, hogyan alakulhat ki egy sajtban a nyom&aacute;s, &eacute;s mi&eacute;rt robbanhat fel, valamint hogyan ker&uuml;lhetj&uuml;k el ezt a kellemetlen helyzetet.</p>\r\n<h2>Mi&eacute;rt robbanhat fel egy t&uacute;l&eacute;rett sajt?</h2>\r\n<p>A sajtok &eacute;rlel&eacute;se sor&aacute;n bakt&eacute;riumok &eacute;s enzimek tev&eacute;kenys&eacute;ge folyt&aacute;n g&aacute;zok keletkeznek, p&eacute;ld&aacute;ul sz&eacute;n-dioxid &eacute;s met&aacute;n. Norm&aacute;l k&ouml;r&uuml;lm&eacute;nyek k&ouml;z&ouml;tt ezek a g&aacute;zok lassan t&aacute;voznak, de ha a sajtot l&eacute;gmentesen lez&aacute;rj&aacute;k vagy t&uacute;l hossz&uacute; ideig &eacute;rlelik, a nyom&aacute;s fel&eacute;p&uuml;lhet.</p>\r\n<ul>\r\n<li>G&aacute;zk&eacute;pződ&eacute;s: A ferment&aacute;ci&oacute; sor&aacute;n a mikroorganizmusok g&aacute;zokat termelnek.</li>\r\n<li>L&eacute;gmentes csomagol&aacute;s: A l&eacute;gmentesen lez&aacute;rt csomagol&aacute;s megakad&aacute;lyozza a g&aacute;zok elsziv&aacute;rg&aacute;s&aacute;t.</li>\r\n<li>T&uacute;l hossz&uacute; &eacute;rlel&eacute;s: Egyes sajtfajt&aacute;k nem b&iacute;rj&aacute;k a hossz&uacute; t&aacute;rol&aacute;st, &eacute;s a g&aacute;zok felgy&uuml;lemlenek.</li>\r\n</ul>\r\n<h3>A k&eacute;mia a h&aacute;tt&eacute;rben</h3>\r\n<p>A sajtokban l&eacute;vő tejsavbakt&eacute;riumok &eacute;s m&aacute;s mikroorganizmusok a cukrok lebont&aacute;sa sor&aacute;n g&aacute;zokat &aacute;ll&iacute;tanak elő. Ha ez a folyamat kontroll&aacute;latlanul zajlik, a belső nyom&aacute;s ak&aacute;r 2-3 atmoszf&eacute;r&aacute;t is el&eacute;rhet, ami elegendő egy csomagol&aacute;s felrobbant&aacute;s&aacute;hoz.</p>\r\n<h2>Hogyan lehet elker&uuml;lni a sajtrobban&aacute;st?</h2>\r\n<p>Szerencs&eacute;re, egyszerű l&eacute;p&eacute;sekkel megelőzhetj&uuml;k, hogy a sajtunk robban&aacute;ssal fenyegetően t&uacute;l&eacute;rett legyen.</p>\r\n<ul>\r\n<li>Megfelelő t&aacute;rol&aacute;s: T&aacute;rold a sajtot hűv&ouml;s, sz&aacute;raz helyen, de ne l&eacute;gmentesen.</li>\r\n<li>Ellenőrizd a lej&aacute;rati d&aacute;tumot: Tartsd be az aj&aacute;nlott fogyaszt&aacute;si időt, k&uuml;l&ouml;n&ouml;sen l&aacute;gy sajtok eset&eacute;n.</li>\r\n<li>Figyeld a jeleket: Duzzad&aacute;s, szokatlan szag vagy sz&iacute;neződ&eacute;s jelezheti a probl&eacute;m&aacute;t.</li>\r\n</ul>\r\n<h3>Gyakori t&eacute;vhitek</h3>\r\n<p>Sokan azt hiszik, hogy csak a pen&eacute;szes sajtok robbanhatnak, de val&oacute;j&aacute;ban b&aacute;rmely t&uacute;l&eacute;rett sajt kock&aacute;zatot jelent. A kem&eacute;ny sajtok is hajlamosak lehetnek a g&aacute;zk&eacute;pződ&eacute;sre, ha nem megfelelően t&aacute;rolj&aacute;k őket.</p>\r\n<h2>Mi a teendő, ha a sajtod t&uacute;l&eacute;rett?</h2>\r\n<p>Ha gyan&uacute;s jeleket &eacute;szlelsz a sajton, ne pr&oacute;b&aacute;ld megnyitni erőszakkal. Helyette k&ouml;vesd ezeket a l&eacute;p&eacute;seket:</p>\r\n<ul>\r\n<li>Vigy&aacute;zz, ne sz&uacute;rd &aacute;t: Ez felgyors&iacute;thatja a robban&aacute;st.</li>\r\n<li>T&aacute;vol&iacute;tsd el biztons&aacute;gosan: Tedd egy v&eacute;dőcsomagol&aacute;sba, &eacute;s dobj ki, vagy k&eacute;rj szak&eacute;rtői seg&iacute;ts&eacute;get.</li>\r\n<li>Ne fogyaszd el: A t&uacute;l&eacute;rett sajt eg&eacute;szs&eacute;g&uuml;gyi kock&aacute;zatot jelenthet.</li>\r\n</ul>\r\n<h2>&Ouml;sszegz&eacute;s: A sajtok biztons&aacute;gos &eacute;lvezete</h2>\r\n<p>A t&uacute;l&eacute;rett sajt robban&aacute;sa ritka, de val&oacute;s jelens&eacute;g, amely a megfelelő t&aacute;rol&aacute;s &eacute;s figyelem hi&aacute;ny&aacute;b&oacute;l ad&oacute;dhat. A sajtok &eacute;lvezet&eacute;hez tartsd be az alapvető t&aacute;rol&aacute;si szab&aacute;lyokat, &eacute;s figyeld az esetleges jeleket. &Iacute;gy biztos lehet benne, hogy a sajtod finom marad, &eacute;s nem v&aacute;ratlan robban&aacute;sokkal lepi meg.</p>', 'published', 'post', '', '', NULL, NULL, NULL);
INSERT INTO `posts` (`id`, `title`, `slug`, `content`, `status`, `post_type`, `meta_title`, `meta_description`, `featured_image`, `publish_at`, `deleted_at`) VALUES ('12', 'Harckocsik a Teve Utcai Óvodában: Játék, Fantázia és Tanulás', 'harckocsik-a-teve-utcai-ovodaban-jatek-fantazia-es-tanulas', '<h2>Bevezet&eacute;s: A Fant&aacute;zia Vil&aacute;ga a Kisgyermekek J&aacute;t&eacute;k&aacute;ban</h2>\r\n<p>A Teve Utcai &Oacute;voda falai k&ouml;z&ouml;tt egyedi j&aacute;t&eacute;kok sz&uuml;letnek, ahol a gyermekek k&eacute;pzelete sz&aacute;rnyal. A \"harckocsik\" itt nem harcot jelentenek, hanem kreat&iacute;v kalandokat, amelyek seg&iacute;tik a fejlőd&eacute;st. Ebben a cikkben megismerj&uuml;k, hogyan alakulnak &aacute;t ezek a j&aacute;t&eacute;kok tanul&aacute;si lehetős&eacute;gekk&eacute; az &oacute;vodai k&ouml;rnyezetben.</p>\r\n<h2>A Harckocsik Szerepe a Gyermekj&aacute;t&eacute;kban</h2>\r\n<p>Az &oacute;vod&aacute;ban a harckocsik gyakran egyszerű j&aacute;t&eacute;kszerek, mint plakett vagy &eacute;p&iacute;tőkock&aacute;k, amelyeket a gyerekek saj&aacute;t t&ouml;rt&eacute;neteikbe fonnak. Ezek a j&aacute;t&eacute;kok sz&aacute;mos fejleszt&eacute;si ter&uuml;letet t&aacute;mogatnak.</p>\r\n<h3>Kognit&iacute;v Fejlőd&eacute;s &eacute;s Problemaold&aacute;s</h3>\r\n<p>A harckocsikkal val&oacute; j&aacute;t&eacute;k sor&aacute;n a gyermekek logik&aacute;t &eacute;s tervez&eacute;si k&eacute;szs&eacute;geket fejlesztenek. P&eacute;ld&aacute;ul:</p>\r\n<ul>\r\n<li>&Uacute;tvonalak tervez&eacute;se k&eacute;pzeletbeli akad&aacute;lyokon &aacute;t.</li>\r\n<li>Sz&aacute;mol&aacute;s vagy sorrendis&eacute;g gyakorl&aacute;sa a j&aacute;t&eacute;k sor&aacute;n.</li>\r\n<li>Ok-okozati &ouml;sszef&uuml;gg&eacute;sek felfedez&eacute;se mozg&aacute;s &eacute;s t&eacute;rbeli t&aacute;j&eacute;koz&oacute;d&aacute;s r&eacute;v&eacute;n.</li>\r\n</ul>\r\n<h3>Szoci&aacute;lis K&eacute;szs&eacute;gek &eacute;s Egy&uuml;ttműk&ouml;d&eacute;s</h3>\r\n<p>Az &oacute;vodai csoportj&aacute;t&eacute;kokban a harckocsik k&ouml;zponti elemekk&eacute; v&aacute;lhatnak, előseg&iacute;tve a t&aacute;rsas kapcsolatokat. A gyerekek megtanulnak:</p>\r\n<ul>\r\n<li>Megosztani a j&aacute;t&eacute;kszereket &eacute;s felv&aacute;ltva j&aacute;tszani.</li>\r\n<li>Kommunik&aacute;lni t&ouml;rt&eacute;neteiket &eacute;s szab&aacute;lyokat egym&aacute;ssal.</li>\r\n<li>Konfliktusokat b&eacute;k&eacute;sen kezelni k&ouml;z&ouml;s c&eacute;lok &eacute;rdek&eacute;ben.</li>\r\n</ul>\r\n<h2>Gyakorlati P&eacute;ld&aacute;k a Teve Utcai &Oacute;vod&aacute;b&oacute;l</h2>\r\n<p>A Teve Utcai &Oacute;voda pedag&oacute;gusai kreat&iacute;v m&oacute;dszereket alkalmaznak a harckocsik integr&aacute;l&aacute;s&aacute;ra a napi tev&eacute;kenys&eacute;gekbe. &Iacute;me n&eacute;h&aacute;ny sikeres gyakorlat:</p>\r\n<ul>\r\n<li><strong>T&ouml;rt&eacute;netmes&eacute;l&eacute;s a Harckocsikkal:</strong> A gyerekek saj&aacute;t kalandokat tal&aacute;lnak ki, fejlesztve a nyelvi k&eacute;szs&eacute;geiket &eacute;s kreativit&aacute;sukat.</li>\r\n<li><strong>&Eacute;p&iacute;tőj&aacute;t&eacute;kok &eacute;s M&eacute;rn&ouml;ki Kih&iacute;v&aacute;sok:</strong> Egyszerű anyagokb&oacute;l, mint karton vagy fa, harckocsikat &eacute;p&iacute;tenek, ami finommotorik&aacute;t &eacute;s tervező gondolkod&aacute;st erős&iacute;t.</li>\r\n<li><strong>Mozg&aacute;sos J&aacute;t&eacute;kok:</strong> Fut&oacute;versenyek vagy akad&aacute;lyp&aacute;ly&aacute;k, ahol a harckocsik szimb&oacute;lumai mozg&aacute;st &eacute;s koordin&aacute;ci&oacute;t &ouml;szt&ouml;n&ouml;znek.</li>\r\n</ul>\r\n<h2>Sz&uuml;lői Tippek: Hogyan T&aacute;mogassuk a J&aacute;t&eacute;kot Otthon</h2>\r\n<p>Az otthoni k&ouml;rnyezetben is k&ouml;nnyen alkalmazhat&oacute;k az &oacute;vodai elvek. &Iacute;me n&eacute;h&aacute;ny javaslat:</p>\r\n<ul>\r\n<li>V&aacute;lasszunk olyan j&aacute;t&eacute;kszereket, amelyek nyitottak a kreat&iacute;v j&aacute;t&eacute;kra, nem csak harci szcen&aacute;ri&oacute;kra.</li>\r\n<li>Besz&eacute;lgess&uuml;nk a gyermekekkel j&aacute;t&eacute;k k&ouml;zben, k&eacute;rdezz&uuml;k meg, milyen t&ouml;rt&eacute;neteket tal&aacute;lnak ki.</li>\r\n<li>Kombin&aacute;ljuk a harckocsikat m&aacute;s j&aacute;t&eacute;kokkal, p&eacute;ld&aacute;ul &eacute;p&iacute;tőkkel vagy műv&eacute;szeti anyagokkal, hogy gazdagabb &eacute;lm&eacute;nyt ny&uacute;jtsunk.</li>\r\n</ul>\r\n<h2>&Ouml;sszegz&eacute;s: A J&aacute;t&eacute;k Mint Tanul&aacute;si Eszk&ouml;z</h2>\r\n<p>A \"harckocsik a Teve Utcai &Oacute;vod&aacute;ban\" nem csup&aacute;n sz&oacute;rakoz&aacute;s, hanem &eacute;rt&eacute;kes pedag&oacute;giai lehetős&eacute;g. A kreat&iacute;v j&aacute;t&eacute;kokon kereszt&uuml;l a gyermekek fejlesztik kognit&iacute;v, szoci&aacute;lis &eacute;s motoros k&eacute;szs&eacute;geiket, mik&ouml;zben &ouml;r&ouml;mmel tanulnak. A kulcs a nyitotts&aacute;g &eacute;s a fant&aacute;zia t&aacute;mogat&aacute;sa mind az &oacute;vod&aacute;ban, mind otthon.</p>', 'published', 'post', '', '', '2026/03/1772884265_db84cc34.jpg', NULL, NULL);

DROP TABLE IF EXISTS `settings`;
CREATE TABLE `settings` (
  `setting_key` varchar(100) NOT NULL,
  `setting_value` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`setting_value`)),
  PRIMARY KEY (`setting_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `settings` (`setting_key`, `setting_value`) VALUES ('ai', '{\"deepseek_api_key\":\"sk-3e97a4d13e8c4b0ea3c7f48e5037c476\"}');
INSERT INTO `settings` (`setting_key`, `setting_value`) VALUES ('design', '{\"footer_text\":\"© 2026\",\"primary_color\":\"#2563eb\"}');
INSERT INTO `settings` (`setting_key`, `setting_value`) VALUES ('site_info', '{\"name\":\"Saját CMS\",\"description\":\"Leírás\"}');

DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `password_hash` varchar(255) DEFAULT NULL,
  `role` varchar(20) DEFAULT 'admin',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `users` (`id`, `username`, `email`, `password_hash`, `role`, `created_at`) VALUES ('1', 'admin', NULL, '$argon2i$v=19$m=65536,t=4,p=1$MjF5U21Jbk5uUlo1SUZwaQ$yPNn9xk3YVQMKnk6iNU8//Pt9xWmcSBjeFKlwQHWqbk', 'super_admin', '2026-03-06 17:15:04');
INSERT INTO `users` (`id`, `username`, `email`, `password_hash`, `role`, `created_at`) VALUES ('2', 'zizike', 'erdentuja@gmail.com', '$argon2i$v=19$m=65536,t=4,p=1$dEQ1a3JaS21zU3N4L0lrRg$snA2if929AfOd3jaeLxe1Ed3hJjnJAQ0UMXps+vCclQ', 'admin', '2026-03-07 12:19:53');

SET FOREIGN_KEY_CHECKS = 1;
