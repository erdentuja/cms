<?php
require_once '../config.php';
require_once '../core/UrlHelper.php';
require_once 'layout.php';

if (!isset($_SESSION['admin_id'])) {
    header('Location: index.php');
    exit;
}

if (!is_admin()) {
    header('Location: index.php');
    exit;
}

$message     = '';
$messageType = '';
$editPost    = null;

// ---------- Aktuális típus (szűrés) ----------
$currentType = $_GET['type'] ?? 'all';

// ---------- Soft Delete (lomtárba) ----------
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_id'])) {
    if (csrf_verify()) {
        $stmt = $db->prepare('SELECT title, post_type FROM posts WHERE id = ?');
        $stmt->execute([$_POST['delete_id']]);
        $delPost = $stmt->fetch();
        $db->prepare('UPDATE posts SET deleted_at = NOW() WHERE id = ?')->execute([$_POST['delete_id']]);
        log_activity($db, 'delete', $delPost['post_type'] ?? 'post', (int)$_POST['delete_id'], $delPost['title'] ?? '');
        $message = 'Lomtárba helyezve.';
        $messageType = 'success';
    }
}

// ---------- Visszaállítás ----------
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['restore_id'])) {
    if (csrf_verify()) {
        $stmt = $db->prepare('SELECT title, post_type FROM posts WHERE id = ?');
        $stmt->execute([$_POST['restore_id']]);
        $resPost = $stmt->fetch();
        $db->prepare('UPDATE posts SET deleted_at = NULL WHERE id = ?')->execute([$_POST['restore_id']]);
        log_activity($db, 'restore', $resPost['post_type'] ?? 'post', (int)$_POST['restore_id'], $resPost['title'] ?? '');
        $message = 'Visszaállítva!';
        $messageType = 'success';
    }
}

// ---------- Végleges törlés ----------
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['purge_id'])) {
    if (csrf_verify()) {
        $stmt = $db->prepare('SELECT title, post_type FROM posts WHERE id = ?');
        $stmt->execute([$_POST['purge_id']]);
        $purPost = $stmt->fetch();
        $db->prepare('DELETE FROM posts WHERE id = ?')->execute([$_POST['purge_id']]);
        log_activity($db, 'purge', $purPost['post_type'] ?? 'post', (int)$_POST['purge_id'], $purPost['title'] ?? '');
        $message = 'Véglegesen törölve.';
        $messageType = 'success';
    }
}

// ---------- Mentés ----------
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save'])) {
    if (!csrf_verify()) {
        $message = 'Érvénytelen kérés.';
        $messageType = 'error';
    } else {
        $title     = trim($_POST['title'] ?? '');
        $baseSlug  = $_POST['slug'] ?: $title;
        $content   = $_POST['content'] ?? '';
        $status    = $_POST['status'] ?? 'published';
        $postType  = $_POST['post_type'] ?? 'page';
        $metaTitle = trim($_POST['meta_title'] ?? '');
        $metaDesc  = trim($_POST['meta_description'] ?? '');
        $featured  = trim($_POST['featured_image'] ?? '');
        $publishAt = !empty($_POST['publish_at']) ? $_POST['publish_at'] : null;
        $postId    = $_POST['post_id'] ?? '';
        $catIds    = $_POST['categories'] ?? [];

        // Ha ütemezett, de nincs dátum → hiba
        if ($status === 'scheduled' && !$publishAt) {
            $message = 'Ütemezett publikáláshoz dátum megadása kötelező.';
            $messageType = 'error';
        } elseif ($title === '') {
            $message = 'A cím megadása kötelező.';
            $messageType = 'error';
        } else {
            // Egyedi slug generálása
            $slug = UrlHelper::generateUniqueSlug($db, $baseSlug, $postId ?: null);

            if ($postId) {
                $db->prepare('UPDATE posts SET title=?, slug=?, content=?, status=?, post_type=?, meta_title=?, meta_description=?, featured_image=?, publish_at=? WHERE id=?')
                   ->execute([$title, $slug, $content, $status, $postType, $metaTitle, $metaDesc, $featured ?: null, $publishAt, $postId]);
                log_activity($db, 'update', $postType, (int)$postId, $title);
                $message = ($postType === 'post' ? 'Bejegyzés' : 'Oldal') . ' frissítve!';
            } else {
                $db->prepare('INSERT INTO posts (title, slug, content, status, post_type, meta_title, meta_description, featured_image, publish_at) VALUES (?,?,?,?,?,?,?,?,?)')
                   ->execute([$title, $slug, $content, $status, $postType, $metaTitle, $metaDesc, $featured ?: null, $publishAt]);
                $postId = $db->lastInsertId();
                log_activity($db, 'create', $postType, (int)$postId, $title);
                $message = ($postType === 'post' ? 'Bejegyzés' : 'Oldal') . ' létrehozva!';
            }
            $messageType = 'success';

            // Kategóriák mentése
            $db->prepare('DELETE FROM post_categories WHERE post_id = ?')->execute([$postId]);
            if (!empty($catIds)) {
                $stmt = $db->prepare('INSERT INTO post_categories (post_id, category_id) VALUES (?, ?)');
                foreach ($catIds as $cid) {
                    $stmt->execute([$postId, $cid]);
                }
            }
        }
    }
}

// ---------- Szerkesztés betöltése ----------
if (isset($_GET['edit'])) {
    $stmt = $db->prepare('SELECT * FROM posts WHERE id = ?');
    $stmt->execute([$_GET['edit']]);
    $editPost = $stmt->fetch();
    if ($editPost) {
        $editPost['_categories'] = $db->prepare('SELECT category_id FROM post_categories WHERE post_id = ?');
        $editPost['_categories']->execute([$editPost['id']]);
        $editPost['_categories'] = $editPost['_categories']->fetchAll(PDO::FETCH_COLUMN);
    }
}

// ---------- Kategóriák lista ----------
try {
    $allCategories = $db->query('SELECT * FROM categories ORDER BY name ASC')->fetchAll();
} catch (PDOException $e) {
    $allCategories = []; // tábla még nem létezik – futtasd a migrációt
}

// ---------- Média lista ----------
$allMedia = $db->query("SELECT * FROM media ORDER BY id DESC")->fetchAll();

// ---------- Post lista ----------
$showTrash = ($currentType === 'trash');

if ($showTrash) {
    $posts = $db->query('SELECT * FROM posts WHERE deleted_at IS NOT NULL ORDER BY deleted_at DESC')->fetchAll();
} elseif ($currentType === 'all') {
    $posts = $db->query('SELECT * FROM posts WHERE deleted_at IS NULL ORDER BY id DESC')->fetchAll();
} else {
    $stmt = $db->prepare('SELECT * FROM posts WHERE post_type = ? AND deleted_at IS NULL ORDER BY id DESC');
    $stmt->execute([$currentType]);
    $posts = $stmt->fetchAll();
}

$trashCount = $db->query('SELECT COUNT(*) FROM posts WHERE deleted_at IS NOT NULL')->fetchColumn();

$pageTitle = 'Tartalom kezelés';
if ($currentType === 'page') $pageTitle = 'Oldalak';
elseif ($currentType === 'post') $pageTitle = 'Bejegyzések';
elseif ($showTrash) $pageTitle = 'Lomtár';

admin_header($pageTitle);
?>

<?php if ($message): ?>
    <div class="alert alert-<?php echo $messageType; ?>"><?php echo htmlspecialchars($message); ?></div>
<?php endif; ?>

<!-- Típus szűrő -->
<div style="display: flex; gap: 8px; margin-bottom: 20px;">
    <a href="posts.php?type=all" class="btn <?php echo $currentType === 'all' ? '' : 'btn-outline'; ?>"
       style="<?php echo $currentType !== 'all' ? 'background:transparent; color:#2563eb; border:1px solid #2563eb;' : ''; ?> text-decoration:none; font-size:0.85rem;">Összes</a>
    <a href="posts.php?type=page" class="btn <?php echo $currentType === 'page' ? '' : 'btn-outline'; ?>"
       style="<?php echo $currentType !== 'page' ? 'background:transparent; color:#2563eb; border:1px solid #2563eb;' : ''; ?> text-decoration:none; font-size:0.85rem;">📄 Oldalak</a>
    <a href="posts.php?type=post" class="btn <?php echo $currentType === 'post' ? '' : 'btn-outline'; ?>"
       style="<?php echo $currentType !== 'post' ? 'background:transparent; color:#2563eb; border:1px solid #2563eb;' : ''; ?> text-decoration:none; font-size:0.85rem;">📰 Bejegyzések</a>
    <?php if ($trashCount > 0): ?>
    <a href="posts.php?type=trash" class="btn"
       style="<?php echo $currentType !== 'trash' ? 'background:transparent; color:#dc2626; border:1px solid #dc2626;' : 'background:#dc2626;'; ?> text-decoration:none; font-size:0.85rem;">🗑️ Lomtár (<?php echo $trashCount; ?>)</a>
    <?php endif; ?>
</div>

<?php if (!$showTrash): ?>
<!-- Szerkesztő form -->
<div style="background: #fff; padding: 25px; border-radius: 10px; border: 1px solid #e5e7eb; margin-bottom: 30px;">
    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 15px;">
        <h3 style="margin: 0;"><?php echo $editPost ? '✏️ Szerkesztés' : '➕ Új tartalom'; ?></h3>
        <button type="button" onclick="openAiModal()" class="btn" style="background:#8b5cf6; color:#fff; display:flex; align-items:center; gap:5px; font-weight:bold;">
            ✨ AI Generálás
        </button>
    </div>
    <form method="post">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="post_id" value="<?php echo $editPost['id'] ?? ''; ?>">

        <div style="display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 15px;">
            <div class="form-group">
                <label>Cím *</label>
                <input type="text" name="title" value="<?php echo htmlspecialchars($editPost['title'] ?? ''); ?>" required style="width: 100%;">
            </div>
            <div class="form-group">
                <label>Slug (URL)</label>
                <input type="text" name="slug" value="<?php echo htmlspecialchars($editPost['slug'] ?? ''); ?>" placeholder="automatikus" style="width: 100%;">
            </div>
            <div class="form-group">
                <label>Típus</label>
                <select name="post_type" id="post-type-select" onchange="toggleCategorySection()" style="width: 100%;">
                    <option value="page" <?php echo ($editPost['post_type'] ?? 'page') === 'page' ? 'selected' : ''; ?>>📄 Oldal</option>
                    <option value="post" <?php echo ($editPost['post_type'] ?? '') === 'post' ? 'selected' : ''; ?>>📰 Bejegyzés</option>
                </select>
            </div>
        </div>

        <div class="form-group" style="margin-bottom: 20px;">
            <label>Tartalom</label>
            <div style="background: #fff; color: #000;">
                <textarea name="content" id="editor"><?php echo htmlspecialchars($editPost['content'] ?? ''); ?></textarea>
            </div>
        </div>

        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin-top: 15px;">
            <!-- Bal oldal: meta + státusz -->
            <div>
                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px;">
                    <div class="form-group">
                        <label>Státusz</label>
                        <select name="status" id="status-select" onchange="togglePublishAt()" style="width: 100%;">
                            <option value="published" <?php echo ($editPost['status'] ?? '') === 'published' ? 'selected' : ''; ?>>● Publikált</option>
                            <option value="draft" <?php echo ($editPost['status'] ?? '') === 'draft' ? 'selected' : ''; ?>>○ Piszkozat</option>
                            <option value="scheduled" <?php echo ($editPost['status'] ?? '') === 'scheduled' ? 'selected' : ''; ?>>⏰ Ütemezett</option>
                        </select>
                    </div>
                    <div class="form-group" id="publish-at-group" style="<?php echo ($editPost['status'] ?? '') !== 'scheduled' ? 'display:none;' : ''; ?>">
                        <label>Publikálás ideje</label>
                        <input type="datetime-local" name="publish_at" value="<?php echo $editPost['publish_at'] ?? ''; ?>" style="width: 100%;">
                    </div>
                </div>
                <div class="form-group">
                    <label>Meta cím (SEO)</label>
                    <input type="text" name="meta_title" value="<?php echo htmlspecialchars($editPost['meta_title'] ?? ''); ?>" style="width: 100%;">
                </div>
                <div class="form-group">
                    <label>Meta leírás (SEO)</label>
                    <input type="text" name="meta_description" value="<?php echo htmlspecialchars($editPost['meta_description'] ?? ''); ?>" style="width: 100%;">
                </div>
            </div>

            <!-- Jobb oldal: kiemelt kép + kategóriák -->
            <div>
                <!-- Kiemelt kép -->
                <div class="form-group">
                    <label>Kiemelt kép</label>
                    <input type="hidden" name="featured_image" id="featured-image-input" value="<?php echo htmlspecialchars($editPost['featured_image'] ?? ''); ?>">
                    <div id="featured-preview" style="margin-bottom: 10px;">
                        <?php if (!empty($editPost['featured_image'])): ?>
                            <img src="../uploads/<?php echo htmlspecialchars($editPost['featured_image']); ?>" style="max-width: 100%; max-height: 150px; border-radius: 6px; border: 1px solid #e5e7eb;">
                        <?php endif; ?>
                    </div>
                    <div style="display: flex; gap: 8px;">
                        <button type="button" class="btn" onclick="openFeaturedModal()" style="font-size: 0.85rem; padding: 6px 14px;">🖼️ Választás</button>
                        <button type="button" class="btn btn-danger" onclick="removeFeatured()" style="font-size: 0.85rem; padding: 6px 14px;">✕ Eltávolítás</button>
                    </div>
                </div>

                <!-- Kategóriák (csak bejegyzéseknél) -->
                <div class="form-group" id="categories-section" style="<?php echo ($editPost['post_type'] ?? 'page') !== 'post' ? 'display:none;' : ''; ?>">
                    <label>Kategóriák</label>
                    <?php if (empty($allCategories)): ?>
                        <p style="color: #94a3b8; font-size: 0.85rem;">Nincs kategória. <a href="categories.php">Hozd létre itt.</a></p>
                    <?php else: ?>
                        <div style="max-height: 150px; overflow-y: auto; border: 1px solid #e5e7eb; border-radius: 6px; padding: 10px;">
                            <?php foreach ($allCategories as $cat): ?>
                                <label style="display: flex; align-items: center; gap: 8px; padding: 4px 0; font-weight: normal; cursor: pointer;">
                                    <input type="checkbox" name="categories[]" value="<?php echo $cat['id']; ?>"
                                        <?php echo in_array($cat['id'], $editPost['_categories'] ?? []) ? 'checked' : ''; ?>>
                                    <?php echo htmlspecialchars($cat['name']); ?>
                                </label>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <div style="display: flex; gap: 10px; margin-top: 15px;">
            <button type="submit" name="save" class="btn btn-success">💾 Mentés</button>
            <?php if ($editPost): ?>
                <a href="posts.php" class="btn" style="text-decoration: none;">Mégse</a>
            <?php endif; ?>
        </div>
    </form>
</div>
<?php endif; ?>

<!-- Lista -->
<?php if (empty($posts)): ?>
    <p style="color: #94a3b8;"><?php echo $showTrash ? 'A lomtár üres.' : 'Nincs tartalom.'; ?></p>
<?php else: ?>
    <table>
        <thead>
            <tr>
                <th style="width: 40px;"></th>
                <th>Cím</th>
                <th>Típus</th>
                <?php if ($showTrash): ?>
                    <th>Törölve</th>
                <?php else: ?>
                    <th>Státusz</th>
                <?php endif; ?>
                <th style="width: 200px;">Műveletek</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($posts as $p): ?>
                <tr>
                    <td>
                        <?php if (!empty($p['featured_image'])): ?>
                            <img src="../uploads/<?php echo htmlspecialchars($p['featured_image']); ?>" style="width: 36px; height: 36px; object-fit: cover; border-radius: 4px;">
                        <?php else: ?>
                            <span style="display: inline-block; width: 36px; height: 36px; background: #f1f5f9; border-radius: 4px;"></span>
                        <?php endif; ?>
                    </td>
                    <td>
                        <strong><?php echo htmlspecialchars($p['title']); ?></strong>
                        <div style="font-size: 0.8rem; color: #94a3b8;"><code><?php echo htmlspecialchars($p['slug']); ?></code></div>
                    </td>
                    <td>
                        <?php echo ($p['post_type'] ?? 'page') === 'post' ? '📰 Bejegyzés' : '📄 Oldal'; ?>
                    </td>
                    <td>
                        <?php if ($showTrash): ?>
                            <span style="color: #dc2626; font-size: 0.85rem;">🗑️ <?php echo date('Y.m.d H:i', strtotime($p['deleted_at'])); ?></span>
                        <?php elseif ($p['status'] === 'published'): ?>
                            <span style="color: #16a34a; font-weight: 600;">● Publikált</span>
                        <?php elseif ($p['status'] === 'scheduled'): ?>
                            <span style="color: #ca8a04; font-weight: 600;">⏰ <?php echo $p['publish_at'] ? date('Y.m.d H:i', strtotime($p['publish_at'])) : 'Ütemezett'; ?></span>
                        <?php else: ?>
                            <span style="color: #94a3b8;">○ Piszkozat</span>
                        <?php endif; ?>
                    </td>
                    <td>
                        <div style="display: flex; gap: 5px;">
                            <?php if ($showTrash): ?>
                                <form method="post" style="display: inline;">
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" name="restore_id" value="<?php echo $p['id']; ?>">
                                    <button type="submit" class="btn btn-success" style="padding: 4px 10px; font-size: 0.8rem;" title="Visszaállítás">♻️</button>
                                </form>
                                <form method="post" style="display: inline;" onsubmit="return confirm('Véglegesen törlöd? Ez nem visszavonható!');">
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" name="purge_id" value="<?php echo $p['id']; ?>">
                                    <button type="submit" class="btn btn-danger" style="padding: 4px 10px; font-size: 0.8rem;" title="Végleges törlés">❌</button>
                                </form>
                            <?php else: ?>
                                <a href="posts.php?edit=<?php echo $p['id']; ?>" class="btn" style="padding: 4px 10px; font-size: 0.8rem; text-decoration: none;">✏️</a>
                                <a href="<?php echo UrlHelper::link($p['slug']); ?>" target="_blank" class="btn btn-success" style="padding: 4px 10px; font-size: 0.8rem; text-decoration: none;">👁️</a>
                                <form method="post" style="display: inline;" onsubmit="return confirm('Lomtárba helyezed?');">
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" name="delete_id" value="<?php echo $p['id']; ?>">
                                    <button type="submit" class="btn btn-danger" style="padding: 4px 10px; font-size: 0.8rem;">🗑️</button>
                                </form>
                            <?php endif; ?>
                        </div>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
<?php endif; ?>

<!-- Kiemelt kép választó modal -->
<div id="featured-modal" style="display:none; position:fixed; inset:0; background:rgba(0,0,0,0.6); z-index:9999; justify-content:center; align-items:center;">
    <div style="background:#fff; border-radius:12px; width:90%; max-width:800px; max-height:80vh; display:flex; flex-direction:column; overflow:hidden;">
        <div style="padding:15px 20px; border-bottom:1px solid #e5e7eb; display:flex; justify-content:space-between; align-items:center;">
            <h3 style="margin:0;">🖼️ Kiemelt kép választása</h3>
            <button onclick="closeFeaturedModal()" style="background:none; border:none; font-size:1.5rem; cursor:pointer; color:#64748b;">✕</button>
        </div>
        <div style="padding:20px; overflow-y:auto; display:grid; grid-template-columns:repeat(auto-fill,minmax(120px,1fr)); gap:12px;">
            <?php foreach ($allMedia as $m):
                $ext = strtolower(pathinfo($m['filepath'], PATHINFO_EXTENSION));
                if (!in_array($ext, ['jpg','jpeg','png','gif','webp','svg'])) continue;
            ?>
                <div onclick="selectFeatured('<?php echo htmlspecialchars($m['filepath']); ?>')"
                     style="cursor:pointer; border:2px solid transparent; border-radius:8px; overflow:hidden; transition:all 0.2s;"
                     onmouseenter="this.style.borderColor='#2563eb'" onmouseleave="this.style.borderColor='transparent'">
                    <img src="../uploads/<?php echo htmlspecialchars($m['filepath']); ?>" style="width:100%;height:100px;object-fit:cover;display:block;">
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</div>

<!-- Média böngésző modal (editor) -->
<div id="media-modal" style="display:none; position:fixed; inset:0; background:rgba(0,0,0,0.6); z-index:9999; justify-content:center; align-items:center;">
    <div style="background:#fff; border-radius:12px; width:90%; max-width:800px; max-height:80vh; display:flex; flex-direction:column; overflow:hidden;">
        <div style="padding:15px 20px; border-bottom:1px solid #e5e7eb; display:flex; justify-content:space-between; align-items:center;">
            <h3 style="margin:0;">🖼️ Média könyvtár</h3>
            <button onclick="closeMediaModal()" style="background:none; border:none; font-size:1.5rem; cursor:pointer; color:#64748b;">✕</button>
        </div>
        <div id="media-grid" style="padding:20px; overflow-y:auto; display:grid; grid-template-columns:repeat(auto-fill,minmax(120px,1fr)); gap:12px;"></div>
    </div>
</div>

<!-- AI Generáló Modal -->
<div id="ai-modal" style="display:none; position:fixed; inset:0; background:rgba(0,0,0,0.7); z-index:9999; justify-content:center; align-items:center;">
    <div style="background:#fff; border-radius:12px; width:90%; max-width:500px; display:flex; flex-direction:column; overflow:hidden;">
        <div style="padding:15px 20px; border-bottom:1px solid #e5e7eb; display:flex; justify-content:space-between; align-items:center;">
            <h3 style="margin:0; color:#8b5cf6;">✨ Tartalom generálása AI-val</h3>
            <button onclick="closeAiModal()" style="background:none; border:none; font-size:1.5rem; cursor:pointer; color:#64748b;">✕</button>
        </div>
        <div style="padding:20px;">
            <div id="ai-form">
                <label style="display:block; margin-bottom:8px; font-weight:600;">Miről szóljon a cikk/oldal?</label>
                <textarea id="ai-topic" style="width:100%; height:100px; padding:10px; border:1px solid #d1d5db; border-radius:6px; margin-bottom:15px; resize:vertical;"></textarea>
                <button type="button" onclick="generateAiContent()" class="btn" style="width:100%; background:#8b5cf6; color:#fff; font-weight:bold; height:44px;">Generálás elindítása</button>
            </div>
            
            <div id="ai-loading" style="display:none; text-align:center; padding:20px 0;">
                <div style="font-size:2rem; animation: spin 2s linear infinite; display:inline-block; margin-bottom:10px;">⏳</div>
                <h4 style="margin:0; color:#1e293b;">Az AI dolgozik...</h4>
                <p style="color:#64748b; font-size:0.9rem; margin-top:5px;">Ez eltarthat 15-30 másodpercig. Ne zárd be az ablakot!</p>
            </div>
            
            <style>@keyframes spin { 100% { transform: rotate(360deg); } }</style>
        </div>
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
<script src="https://cdn.tiny.cloud/1/mreq42swlega29mwpkjagy86dm94cdud6s39ocbnufrv2ok4/tinymce/7/tinymce.min.js" referrerpolicy="origin"></script>
<script>
// TinyMCE Editor
let tinymceInstance = null;

tinymce.init({
    selector: '#editor',
    height: 500,
    menubar: true,
    plugins: [
        'advlist', 'autolink', 'lists', 'link', 'image', 'charmap', 'preview',
        'anchor', 'searchreplace', 'visualblocks', 'code', 'fullscreen',
        'insertdatetime', 'media', 'table', 'help', 'wordcount'
    ],
    toolbar: 'undo redo | blocks | bold italic underline strikethrough | ' +
        'alignleft aligncenter alignright alignjustify | ' +
        'bullist numlist outdent indent | medialib link image media | ' +
        'removeformat code fullscreen help',

    // Custom button: Média könyvtár
    setup: function(editor) {
        tinymceInstance = editor;

        // Média könyvtár gomb hozzáadása
        editor.ui.registry.addButton('medialib', {
            text: '🖼️ Média',
            tooltip: 'Média könyvtár megnyitása',
            onAction: function() {
                openMediaModal();
            }
        });

        // Change event az auto-save-hez
        editor.on('change keyup', function() {
            if (typeof markDirty === 'function') {
                markDirty();
            }
        });
    },

    // Tartalom stílus
    content_style: 'body { font-family: Arial, sans-serif; font-size: 14px; }',

    // Automatikus link felismerés
    link_default_target: '_blank',

    // Kép beállítások
    image_advtab: true,
    image_caption: true,

    // Responsive
    resize: true,

    // Automatikus URL konverzió
    relative_urls: false,
    remove_script_host: false
});

// --- Média modal (editor) ---
function openMediaModal() {
    const modal = document.getElementById('media-modal');
    const grid = document.getElementById('media-grid');
    modal.style.display = 'flex';
    grid.innerHTML = '<p style="color:#94a3b8;grid-column:1/-1;text-align:center;">Betöltés...</p>';

    fetch('media_api.php').then(r => r.json()).then(items => {
        grid.innerHTML = '';
        items.filter(i => i.is_image).forEach(item => {
            const div = document.createElement('div');
            div.style.cssText = 'cursor:pointer;border:2px solid transparent;border-radius:8px;overflow:hidden;transition:all 0.2s;';
            div.innerHTML = `<img src="${item.url}" style="width:100%;height:100px;object-fit:cover;display:block;" title="${item.filename}">`;
            div.onmouseenter = () => div.style.borderColor = '#2563eb';
            div.onmouseleave = () => div.style.borderColor = 'transparent';
            div.onclick = () => {
                // TinyMCE-be szúrás
                if (tinymceInstance) {
                    tinymceInstance.insertContent(`<img src="${item.url}" alt="${item.alt_text || item.filename}" style="max-width:100%;height:auto;">`);
                }
                closeMediaModal();
            };
            grid.appendChild(div);
        });
        if (items.filter(i => i.is_image).length === 0) grid.innerHTML = '<p style="color:#94a3b8;grid-column:1/-1;text-align:center;">Nincs kép.</p>';
    });
}
function closeMediaModal() { document.getElementById('media-modal').style.display = 'none'; }


// --- Kiemelt kép modal ---
function openFeaturedModal() { document.getElementById('featured-modal').style.display = 'flex'; }
function closeFeaturedModal() { document.getElementById('featured-modal').style.display = 'none'; }
function selectFeatured(path) {
    document.getElementById('featured-image-input').value = path;
    document.getElementById('featured-preview').innerHTML = `<img src="../uploads/${path}" style="max-width:100%;max-height:150px;border-radius:6px;border:1px solid #e5e7eb;">`;
    closeFeaturedModal();
}
function removeFeatured() {
    document.getElementById('featured-image-input').value = '';
    document.getElementById('featured-preview').innerHTML = '';
}

// --- Toggle-ök ---
function toggleCategorySection() {
    const type = document.getElementById('post-type-select').value;
    document.getElementById('categories-section').style.display = type === 'post' ? '' : 'none';
}
function togglePublishAt() {
    const status = document.getElementById('status-select').value;
    document.getElementById('publish-at-group').style.display = status === 'scheduled' ? '' : 'none';
}

// ESC = modálok bezárása
document.addEventListener('keydown', e => { if (e.key === 'Escape') { closeMediaModal(); closeFeaturedModal(); closeAiModal(); } });

// ========================================
// AI GENERÁLÁS
// ========================================
function openAiModal() {
    document.getElementById('ai-form').style.display = 'block';
    document.getElementById('ai-loading').style.display = 'none';
    document.getElementById('ai-modal').style.display = 'flex';
    document.getElementById('ai-topic').focus();
}

function closeAiModal() {
    document.getElementById('ai-modal').style.display = 'none';
}

function generateAiContent() {
    const topic = document.getElementById('ai-topic').value.trim();
    if (!topic) {
        alert('Kérlek add meg, miről szóljon a cikk!');
        return;
    }

    document.getElementById('ai-form').style.display = 'none';
    document.getElementById('ai-loading').style.display = 'block';

    fetch('ajax_ai_generate.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ topic: topic })
    })
    .then(r => r.json())
    .then(data => {
        closeAiModal();
        if (data.success) {
            // Mezők kitöltése
            document.querySelector('input[name="title"]').value = data.title;

            // TinyMCE frissítése
            if (tinymceInstance) {
                tinymceInstance.setContent(data.content);
            }

            // Kiemelt kép
            if (data.featured_image) {
                document.getElementById('featured-image-input').value = data.featured_image;
                document.getElementById('featured-preview').innerHTML = `<img src="../uploads/${data.featured_image}" style="max-width:100%;max-height:150px;border-radius:6px;border:1px solid #e5e7eb;">`;
            }

            // Generáljunk egy triggert, hogy az isDirty/autosave is észrevegye
            if (typeof markDirty === 'function') {
                markDirty();
            }
            document.querySelector('form[method="post"]').dispatchEvent(new Event('change'));

            alert('✅ A tartalom és a kép sikeresen generálva!');
        } else {
            alert('❌ Hiba történt: ' + data.error);
        }
    })
    .catch(err => {
        closeAiModal();
        alert('❌ Hálózati hiba történt az AI kérés közben.');
        console.error(err);
    });
}

// ========================================
// AUTO-SAVE FUNKCIÓ
// ========================================
(function() {
    const AUTO_SAVE_INTERVAL = 30000; // 30 másodperc
    const LOCALSTORAGE_KEY = 'cms_autosave_backup';

    let autoSaveTimer = null;
    let lastSavedContent = '';
    let lastAutoSaveTime = null;
    let isDirty = false;

    // Státusz megjelenítő elem létrehozása
    const statusDiv = document.createElement('div');
    statusDiv.id = 'autosave-status';
    statusDiv.style.cssText = 'position:fixed;top:70px;right:20px;background:#fff;padding:8px 15px;border-radius:6px;box-shadow:0 2px 8px rgba(0,0,0,0.1);font-size:0.85rem;color:#64748b;border:1px solid #e5e7eb;z-index:1000;opacity:1;transition:opacity 0.3s;';
    statusDiv.textContent = '💾 Auto-save aktív';
    document.body.appendChild(statusDiv);

    // Kezdeti üzenet elrejtése 2 másodperc után
    setTimeout(() => {
        statusDiv.style.opacity = '0';
    }, 2000);

    function showStatus(message, type = 'info') {
        const colors = {
            info: '#64748b',
            success: '#16a34a',
            error: '#dc2626',
            saving: '#2563eb'
        };
        statusDiv.textContent = message;
        statusDiv.style.color = colors[type] || colors.info;
        statusDiv.style.opacity = '1';

        setTimeout(() => {
            statusDiv.style.opacity = '0';
        }, 3000);
    }

    function getFormData() {
        const form = document.querySelector('form[method="post"]');
        if (!form) return null;

        // TinyMCE tartalom lekérése
        const content = tinymceInstance ? tinymceInstance.getContent() : '';

        return {
            post_id: form.querySelector('input[name="post_id"]')?.value || null,
            title: form.querySelector('input[name="title"]')?.value || '',
            slug: form.querySelector('input[name="slug"]')?.value || '',
            content: content,
            post_type: form.querySelector('select[name="post_type"]')?.value || 'page',
            status: form.querySelector('select[name="status"]')?.value || 'draft',
            meta_title: form.querySelector('input[name="meta_title"]')?.value || '',
            meta_description: form.querySelector('input[name="meta_description"]')?.value || '',
            featured_image: form.querySelector('input[name="featured_image"]')?.value || '',
            publish_at: form.querySelector('input[name="publish_at"]')?.value || ''
        };
    }

    function saveToLocalStorage(data) {
        try {
            localStorage.setItem(LOCALSTORAGE_KEY, JSON.stringify({
                data: data,
                timestamp: Date.now()
            }));
        } catch (e) {
            console.error('LocalStorage mentés hiba:', e);
        }
    }

    function clearLocalStorage() {
        try {
            localStorage.removeItem(LOCALSTORAGE_KEY);
        } catch (e) {
            console.error('LocalStorage törlés hiba:', e);
        }
    }

    function autoSave() {
        const data = getFormData();
        if (!data || !data.title) {
            return; // Ne mentsünk, ha nincs cím
        }

        const currentContent = JSON.stringify(data);

        // Ha nem változott semmi, ne mentsünk
        if (currentContent === lastSavedContent) {
            return;
        }

        // LocalStorage backup
        saveToLocalStorage(data);

        // Szerver mentés
        showStatus('⏳ Mentés...', 'saving');

        fetch('autosave_api.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: currentContent
        })
        .then(response => response.json())
        .then(result => {
            if (result.success) {
                lastSavedContent = currentContent;
                lastAutoSaveTime = new Date();
                isDirty = false;

                // Ha új bejegyzés lett létrehozva, frissítsük a post_id mezőt
                if (result.action === 'created' && result.post_id) {
                    const postIdInput = document.querySelector('input[name="post_id"]');
                    if (postIdInput) {
                        postIdInput.value = result.post_id;
                    }
                    // URL frissítés hogy a szerkesztés folytatható legyen
                    const newUrl = 'posts.php?edit=' + result.post_id;
                    window.history.replaceState({}, '', newUrl);
                }

                showStatus('✓ Automatikusan mentve', 'success');
                clearLocalStorage();
                updateLastSavedDisplay();
            } else {
                showStatus('✗ Mentési hiba', 'error');
            }
        })
        .catch(error => {
            console.error('Auto-save hiba:', error);
            showStatus('✗ Szerver hiba (LocalStorage mentve)', 'error');
        });
    }

    function updateLastSavedDisplay() {
        if (!lastAutoSaveTime) return;

        const now = new Date();
        const diff = Math.floor((now - lastAutoSaveTime) / 1000); // másodpercek

        let message = '';
        if (diff < 60) {
            message = `💾 Utolsó mentés: ${diff} mp`;
        } else if (diff < 3600) {
            message = `💾 Utolsó mentés: ${Math.floor(diff / 60)} perce`;
        } else {
            message = `💾 Utolsó mentés: ${Math.floor(diff / 3600)} órája`;
        }

        statusDiv.textContent = message;
        statusDiv.style.opacity = '0.7';
        statusDiv.style.color = '#64748b';
    }

    // Változás figyelése
    function markDirty() {
        isDirty = true;
    }

    // Form mezők változásának figyelése
    const form = document.querySelector('form[method="post"]');
    if (form) {
        form.addEventListener('input', markDirty);
        form.addEventListener('change', markDirty);
    }

    // TinyMCE változás figyelése már a setup-ban be van állítva

    // Auto-save indítása
    autoSaveTimer = setInterval(autoSave, AUTO_SAVE_INTERVAL);

    // Oldal bezárása előtti figyelmeztetés ha van mentetlen változás
    window.addEventListener('beforeunload', function(e) {
        if (isDirty) {
            e.preventDefault();
            e.returnValue = '';
            return '';
        }
    });

    // Form elküldésekor töröljük a LocalStorage-t
    if (form) {
        form.addEventListener('submit', function(e) {
            // Ha a mentés gomb volt megnyomva
            if (e.submitter && e.submitter.name === 'save') {
                clearLocalStorage();
                isDirty = false;
            }
        });
    }

    // LocalStorage helyreállítás ellenőrzése
    try {
        const saved = localStorage.getItem(LOCALSTORAGE_KEY);
        if (saved) {
            const parsed = JSON.parse(saved);
            const age = Date.now() - parsed.timestamp;

            // Ha 24 órán belül van, felajánljuk a helyreállítást
            if (age < 24 * 60 * 60 * 1000) {
                if (confirm('🔄 Találtam egy mentetlen változatot (' + Math.floor(age / 60000) + ' perce). Szeretnéd visszaállítani?')) {
                    const data = parsed.data;

                    // Mezők kitöltése
                    if (data.title) form.querySelector('input[name="title"]').value = data.title;
                    if (data.slug) form.querySelector('input[name="slug"]').value = data.slug;
                    if (data.content && tinymceInstance) tinymceInstance.setContent(data.content);
                    if (data.post_type) form.querySelector('select[name="post_type"]').value = data.post_type;
                    if (data.status) form.querySelector('select[name="status"]').value = data.status;
                    if (data.meta_title) form.querySelector('input[name="meta_title"]').value = data.meta_title;
                    if (data.meta_description) form.querySelector('input[name="meta_description"]').value = data.meta_description;
                    if (data.featured_image) {
                        form.querySelector('input[name="featured_image"]').value = data.featured_image;
                        document.getElementById('featured-preview').innerHTML = `<img src="../uploads/${data.featured_image}" style="max-width:100%;max-height:150px;border-radius:6px;border:1px solid #e5e7eb;">`;
                    }

                    showStatus('✓ Visszaállítva LocalStorage-ból', 'success');
                    isDirty = true;
                } else {
                    clearLocalStorage();
                }
            } else {
                // Túl régi, töröljük
                clearLocalStorage();
            }
        }
    } catch (e) {
        console.error('LocalStorage betöltés hiba:', e);
    }

    // Utolsó mentés idő frissítése minden percben
    setInterval(updateLastSavedDisplay, 60000);

    console.log('✓ Auto-save funkció aktiválva (30 mp)');
})();
</script>

<?php
admin_footer();
